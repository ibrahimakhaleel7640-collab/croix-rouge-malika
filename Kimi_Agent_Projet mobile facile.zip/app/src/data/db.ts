import type { Database } from '@/types';

export const DB: Database = {
  users: [
    { id: 1, prenom: 'Moussa', nom: 'Diallo', email: 'admin@croix-rouge-malika.sn', password: 'admin123', tel: '+221 77 123 45 67', adresse: 'Malika Centre', competences: 'Gestion, Premiers secours', role: 'super_admin', statut: 'actif', dob: '1985-03-15', experiences: '15 ans bénévolat CR', cv: null, created: '2024-01-10' },
    { id: 2, prenom: 'Aminata', nom: 'Sow', email: 'resp@croix-rouge-malika.sn', password: 'resp123', tel: '+221 78 234 56 78', adresse: 'Malika Nord', competences: 'Administration, Finances', role: 'admin', statut: 'actif', dob: '1990-06-20', experiences: 'Admin CR depuis 2018', cv: null, created: '2024-01-15' },
    { id: 3, prenom: 'Fatou', nom: 'Ndiaye', email: 'fatou@example.com', password: 'vol123', tel: '+221 76 345 67 89', adresse: 'Malika Est', competences: 'Infirmière, Premiers secours', role: 'volontaire', statut: 'actif', dob: '1998-11-05', experiences: 'Infirmière hopital Pikine', cv: null, created: '2024-02-01' },
    { id: 4, prenom: 'Ibrahima', nom: 'Coulibaly', email: 'ibra@example.com', password: 'vol123', tel: '+221 70 456 78 90', adresse: 'Malika Ouest', competences: 'Logistique, Conduite', role: 'volontaire', statut: 'actif', dob: '1995-04-12', experiences: '2 ans bénévolat', cv: null, created: '2024-02-10' },
    { id: 5, prenom: 'Mariama', nom: 'Ba', email: 'mariama@example.com', password: 'vol123', tel: '+221 77 567 89 01', adresse: 'Malika Sud', competences: 'Cuisine, Aide sociale', role: 'volontaire', statut: 'actif', dob: '2000-08-25', experiences: 'Aide aux personnes âgées', cv: null, created: '2024-03-05' },
    { id: 6, prenom: 'Ousmane', nom: 'Diop', email: 'ousmane@example.com', password: 'vol123', tel: '+221 78 678 90 12', adresse: 'Malika Centre', competences: 'Informatique, Communication', role: 'volontaire', statut: 'en-attente', dob: '1997-01-30', experiences: 'Développeur web', cv: null, created: '2024-03-15' },
    { id: 7, prenom: 'Aïssatou', nom: 'Diallo', email: 'aissatou@example.com', password: 'vol123', tel: '+221 76 789 01 23', adresse: 'Malika Nord', competences: 'Psychologie, Écoute', role: 'chef_equipe', statut: 'actif', dob: '1992-09-18', experiences: 'Psychologue clinique', cv: null, created: '2024-04-01' },
  ],
  activities: [
    { id: 1, nom: 'Distribution alimentaire Ramadan', desc: 'Distribution de colis alimentaires aux familles dans le besoin pendant le Ramadan', date: '2025-03-25', lieu: 'Mosquée centrale Malika', statut: 'terminee', limite: 100, chefId: 7, created: '2025-03-01' },
    { id: 2, nom: 'Campagne de vaccination', desc: 'Vaccination des enfants de 0 à 5 ans contre la rougeole et la polio', date: '2025-04-15', lieu: 'Centre de Santé Malika', statut: 'prevue', limite: 200, chefId: 3, created: '2025-03-10' },
    { id: 3, nom: 'Formation premiers secours', desc: 'Formation aux gestes de premiers secours pour les volontaires et la communauté', date: '2025-04-20', lieu: 'Mairie de Malika', statut: 'prevue', limite: 30, chefId: 7, created: '2025-03-15' },
    { id: 4, nom: 'Journée de sensibilisation eau', desc: 'Sensibilisation sur la qualité de l\'eau et l\'assainissement', date: '2025-04-05', lieu: 'École Malika 1', statut: 'en-cours', limite: 80, chefId: 3, created: '2025-03-20' },
    { id: 5, nom: 'Visite aux personnes âgées', desc: 'Visites à domicile et soutien aux personnes âgées isolées', date: '2025-03-30', lieu: 'Quartiers de Malika', statut: 'terminee', limite: 20, chefId: 5, created: '2025-03-25' },
  ],
  participants: [
    { id: 1, userId: 3, actId: 1, role: 'responsable', date: '2025-03-01' },
    { id: 2, userId: 4, actId: 1, role: 'participant', date: '2025-03-01' },
    { id: 3, userId: 5, actId: 1, role: 'participant', date: '2025-03-02' },
    { id: 4, userId: 3, actId: 2, role: 'responsable', date: '2025-03-10' },
    { id: 5, userId: 7, actId: 2, role: 'participant', date: '2025-03-10' },
    { id: 6, userId: 4, actId: 3, role: 'participant', date: '2025-03-15' },
    { id: 7, userId: 5, actId: 3, role: 'participant', date: '2025-03-16' },
    { id: 8, userId: 6, actId: 4, role: 'observateur', date: '2025-03-20' },
    { id: 9, userId: 3, actId: 5, role: 'participant', date: '2025-03-25' },
    { id: 10, userId: 5, actId: 5, role: 'responsable', date: '2025-03-25' },
  ],
  finances: [
    { id: 1, userId: 3, montant: 5000, type: 'cotisation', mode: 'cash', ref: 'COT-2025-001', date: '2025-01-15', actId: null },
    { id: 2, userId: 4, montant: 5000, type: 'cotisation', mode: 'wave', ref: 'COT-2025-002', date: '2025-01-20', actId: null },
    { id: 3, userId: 5, montant: 3000, type: 'cotisation', mode: 'orange_money', ref: 'COT-2025-003', date: '2025-02-05', actId: null },
    { id: 4, userId: 7, montant: 10000, type: 'don', mode: 'virement', ref: 'DON-2025-001', date: '2025-02-10', actId: null },
    { id: 5, userId: 3, montant: 2000, type: 'frais_activite', mode: 'cash', ref: 'FRAC-2025-001', date: '2025-03-25', actId: 1 },
    { id: 6, userId: 6, montant: 5000, type: 'cotisation', mode: 'free_money', ref: 'COT-2025-004', date: '2025-03-15', actId: null },
    { id: 7, userId: 4, montant: 15000, type: 'don', mode: 'wave', ref: 'DON-2025-002', date: '2025-03-20', actId: null },
    { id: 8, userId: 5, montant: 5000, type: 'cotisation', mode: 'cash', ref: 'COT-2025-005', date: '2025-04-01', actId: null },
  ],
  admins: [
    { id: 1, prenom: 'Moussa', nom: 'Diallo', email: 'admin@croix-rouge-malika.sn', role: 'super_admin', lastAccess: 'Maintenant' },
    { id: 2, prenom: 'Aminata', nom: 'Sow', email: 'resp@croix-rouge-malika.sn', role: 'admin', lastAccess: 'Aujourd\'hui' },
  ],
  notifications: [],
  nextId: { users: 8, activities: 6, participants: 11, finances: 9, admins: 3 }
};

// Helper functions
export const roleLabel = (r: string): string => {
  const map: Record<string, string> = {
    super_admin: 'Super Admin',
    admin: 'Administrateur',
    volontaire: 'Volontaire',
    chef_equipe: "Chef d'équipe"
  };
  return map[r] || r;
};

export const statusBadge = (statut: string): string => {
  const map: Record<string, string> = {
    actif: 'bg-green-100 text-green-700',
    'en-attente': 'bg-yellow-100 text-yellow-700',
    suspendu: 'bg-red-100 text-red-700',
    prevue: 'bg-blue-100 text-blue-700',
    'en-cours': 'bg-amber-100 text-amber-700',
    terminee: 'bg-green-100 text-green-700'
  };
  return map[statut] || 'bg-gray-100 text-gray-700';
};

export const statusLabel = (statut: string): string => {
  const map: Record<string, string> = {
    actif: 'Actif',
    'en-attente': 'En attente',
    suspendu: 'Suspendu',
    prevue: 'Prévue',
    'en-cours': 'En cours',
    terminee: 'Terminée'
  };
  return map[statut] || statut;
};

export const financeTypeBadge = (type: string): string => {
  const map: Record<string, string> = {
    cotisation: 'bg-blue-100 text-blue-700',
    don: 'bg-green-100 text-green-700',
    frais_activite: 'bg-amber-100 text-amber-700'
  };
  return map[type] || 'bg-gray-100 text-gray-700';
};
