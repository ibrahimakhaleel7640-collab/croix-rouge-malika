import React, { createContext, useContext, useState, useCallback } from 'react';
import type { User } from '@/types';
import { DB } from '@/data/db';

interface AuthContextType {
  currentUser: User | null;
  login: (email: string, password: string) => boolean;
  logout: () => void;
  register: (userData: Partial<User>) => { success: boolean; message: string };
  updateUser: (userData: Partial<User>) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [currentUser, setCurrentUser] = useState<User | null>(null);

  const login = useCallback((email: string, password: string): boolean => {
    const user = DB.users.find(u => u.email === email && u.password === password);
    if (user) {
      setCurrentUser(user);
      return true;
    }
    return false;
  }, []);

  const logout = useCallback(() => {
    setCurrentUser(null);
  }, []);

  const register = useCallback((userData: Partial<User>): { success: boolean; message: string } => {
    const { prenom, nom, email, password, tel } = userData;
    
    if (!prenom || !nom || !email || !password) {
      return { success: false, message: 'Les champs marqués * sont obligatoires.' };
    }
    
    if (DB.users.find(u => u.email === email)) {
      return { success: false, message: 'Cet email est déjà utilisé.' };
    }
    
    if (password.length < 6) {
      return { success: false, message: 'Le mot de passe doit contenir au moins 6 caractères.' };
    }
    
    const newUser: User = {
      id: DB.nextId.users++,
      prenom: prenom || '',
      nom: nom || '',
      email: email || '',
      password: password || '',
      tel: tel || '',
      adresse: userData.adresse || '',
      dob: userData.dob || '',
      competences: userData.competences || '',
      experiences: userData.experiences || '',
      role: 'volontaire',
      statut: 'en-attente',
      cv: null,
      created: new Date().toISOString().split('T')[0]
    };
    
    DB.users.push(newUser);
    return { success: true, message: 'Compte créé avec succès ! Votre compte est en attente de validation.' };
  }, []);

  const updateUser = useCallback((userData: Partial<User>) => {
    if (!currentUser) return;
    
    const idx = DB.users.findIndex(u => u.id === currentUser.id);
    if (idx !== -1) {
      DB.users[idx] = { ...DB.users[idx], ...userData };
      setCurrentUser({ ...DB.users[idx] });
    }
  }, [currentUser]);

  return (
    <AuthContext.Provider value={{ currentUser, login, logout, register, updateUser }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
