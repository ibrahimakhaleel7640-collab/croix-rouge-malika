import { useEffect, useState } from 'react';
import { DB } from '@/data/db';
import { Stethoscope, AlertTriangle, UtensilsCrossed, GraduationCap, HeartHandshake, Droplets } from 'lucide-react';

interface HomeProps {
  onNavigate: (page: string) => void;
}

export function Home({ onNavigate }: HomeProps) {
  const [stats, setStats] = useState({
    volontaires: 0,
    activites: 0,
    participants: 0,
    cotisations: 0
  });

  useEffect(() => {
    const actives = DB.users.filter(u => u.statut === 'actif' && u.role === 'volontaire').length;
    const total = DB.finances.reduce((s, f) => s + f.montant, 0);
    setStats({
      volontaires: actives,
      activites: DB.activities.length,
      participants: DB.participants.length,
      cotisations: total
    });
  }, []);

  const missions = [
    {
      icon: <Stethoscope className="w-6 h-6 text-[#CC0000]" />,
      title: 'Santé Communautaire',
      desc: 'Consultations médicales gratuites, vaccination, sensibilisation aux maladies et soutien aux personnes vulnérables.'
    },
    {
      icon: <AlertTriangle className="w-6 h-6 text-[#CC0000]" />,
      title: "Secours d'Urgence",
      desc: 'Intervention rapide lors de catastrophes, incendies, accidents et situations d\'urgence dans la communauté.'
    },
    {
      icon: <UtensilsCrossed className="w-6 h-6 text-[#CC0000]" />,
      title: 'Aide Alimentaire',
      desc: 'Distribution de vivres aux familles démunies, banque alimentaire et soutien nutritionnel aux enfants.'
    },
    {
      icon: <GraduationCap className="w-6 h-6 text-[#CC0000]" />,
      title: 'Formation & Sensibilisation',
      desc: 'Premiers secours, hygiène, prévention des risques et éducation sanitaire pour toute la communauté.'
    },
    {
      icon: <HeartHandshake className="w-6 h-6 text-[#CC0000]" />,
      title: 'Soutien aux Personnes Âgées',
      desc: 'Visites à domicile, accompagnement et assistance quotidienne pour les personnes âgées isolées.'
    },
    {
      icon: <Droplets className="w-6 h-6 text-[#CC0000]" />,
      title: 'Eau & Assainissement',
      desc: 'Accès à l\'eau potable, sensibilisation à l\'hygiène et amélioration des conditions sanitaires à Malika.'
    }
  ];

  return (
    <div>
      {/* Hero Section */}
      <div className="relative bg-gradient-to-br from-[#990000] via-[#CC0000] to-[#E83333] text-white py-12 md:py-20 px-4 md:px-8 text-center overflow-hidden">
        {/* Pattern overlay */}
        <div 
          className="absolute inset-0 opacity-[0.04]"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
          }}
        />
        
        <div className="relative z-10">
          <div className="inline-block bg-white/15 border border-white/30 px-4 md:px-5 py-1.5 md:py-2 rounded-full text-[0.65rem] md:text-xs font-medium tracking-widest uppercase mb-4 md:mb-6">
            🇸🇳 Communauté de Malika, Sénégal
          </div>
          <h1 className="font-serif text-2xl sm:text-3xl md:text-4xl lg:text-5xl xl:text-6xl font-black leading-tight mb-4 md:mb-6">
            Ensemble, nous sauvons<br className="hidden sm:block" />des vies à Malika
          </h1>
          <p className="text-sm md:text-base lg:text-lg opacity-90 max-w-xl mx-auto mb-6 md:mb-10 px-4">
            La Croix-Rouge de Malika mobilise volontaires et ressources pour venir en aide aux populations vulnérables de notre communauté.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center px-4">
            <button 
              onClick={() => onNavigate('register')}
              className="px-6 md:px-8 py-3 md:py-4 bg-white text-[#CC0000] rounded-full font-semibold hover:bg-[#FAF7F2] transition-all hover:-translate-y-0.5 text-sm md:text-base"
            >
              Devenir Volontaire
            </button>
            <button 
              onClick={() => onNavigate('activities-public')}
              className="px-6 md:px-8 py-3 md:py-4 border-2 border-white text-white rounded-full font-semibold hover:bg-white/15 transition-all hover:-translate-y-0.5 text-sm md:text-base"
            >
              Voir les Activités
            </button>
          </div>
        </div>
      </div>

      {/* Stats Strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 bg-[#1A1A1A] text-white">
        {[
          { value: stats.volontaires, label: 'Volontaires' },
          { value: stats.activites, label: 'Activités' },
          { value: stats.participants, label: 'Participants' },
          { value: stats.cotisations.toLocaleString(), label: 'FCFA collectés' }
        ].map((stat, i) => (
          <div key={i} className="py-4 md:py-8 px-2 md:px-4 text-center border-r border-white/10 last:border-r-0">
            <span className="font-serif text-xl md:text-3xl lg:text-4xl font-black text-[#F0C060]">{stat.value}</span>
            <div className="text-[0.6rem] md:text-xs opacity-60 uppercase tracking-wider mt-1">{stat.label}</div>
          </div>
        ))}
      </div>

      {/* Missions Section */}
      <div className="py-10 md:py-16 px-4 md:px-8 max-w-6xl mx-auto">
        <h2 className="font-serif text-xl md:text-3xl font-bold text-[#1A1A1A] mb-1 md:mb-2">Nos Missions</h2>
        <p className="text-gray-600 text-sm md:text-base mb-6 md:mb-10">Interventions humanitaires au cœur de Malika</p>
        
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
          {missions.map((mission, i) => (
            <div 
              key={i}
              className="bg-white rounded-xl p-5 md:p-8 shadow-[0_4px_24px_rgba(0,0,0,0.08)] border-t-4 border-[#CC0000] hover:-translate-y-1 hover:shadow-[0_8px_48px_rgba(0,0,0,0.16)] transition-all"
            >
              <div className="w-10 h-10 md:w-14 md:h-14 bg-red-50 rounded-lg flex items-center justify-center mb-3 md:mb-5">
                {mission.icon}
              </div>
              <h3 className="font-serif text-base md:text-lg font-bold text-[#1A1A1A] mb-2 md:mb-3">{mission.title}</h3>
              <p className="text-gray-600 text-xs md:text-sm leading-relaxed">{mission.desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-[#1A1A1A] text-white/60 text-center py-4 md:py-6 text-xs md:text-sm mt-8 md:mt-12">
        <strong className="text-[#CC0000]">✚ Croix-Rouge – Malika</strong> · Dakar, Sénégal
        <div className="mt-1 md:mt-2">Développé avec ❤️ pour la communauté · 2025</div>
      </footer>
    </div>
  );
}
