// Public Activities Page
import { DB, statusBadge, statusLabel } from '@/data/db';
import { Calendar, MapPin, Users, User } from 'lucide-react';

export function PublicActivities() {
  const activities = DB.activities;

  return (
    <div className="py-8 md:py-12 px-4 md:px-8 max-w-5xl mx-auto">
      <div className="mb-6 md:mb-8">
        <h1 className="font-serif text-xl md:text-3xl font-bold text-[#1A1A1A] mb-2">📅 Activités de la Communauté</h1>
        <p className="text-gray-600 text-sm md:text-base">Toutes les activités organisées par la Croix-Rouge de Malika</p>
      </div>

      <div className="space-y-4 md:space-y-6">
        {activities.length === 0 ? (
          <div className="text-center py-12 md:py-16 text-gray-500">
            <div className="text-4xl md:text-5xl mb-4">📅</div>
            <h3 className="text-base md:text-lg font-semibold mb-2">Aucune activité</h3>
            <p className="text-sm">Aucune activité n'est programmée pour le moment.</p>
          </div>
        ) : (
          activities.map(activity => {
            const chef = DB.users.find(u => u.id === activity.chefId);
            const participants = DB.participants.filter(p => p.actId === activity.id).length;
            
            return (
              <div 
                key={activity.id}
                className="bg-white rounded-xl p-4 md:p-6 shadow-[0_4px_24px_rgba(0,0,0,0.08)] hover:shadow-[0_8px_48px_rgba(0,0,0,0.12)] transition-shadow"
              >
                <div className="flex flex-col sm:flex-row justify-between items-start gap-2 sm:gap-4 mb-3 md:mb-4">
                  <h3 className="font-serif text-base md:text-xl font-bold text-[#1A1A1A]">{activity.nom}</h3>
                  <span className={`px-2 md:px-3 py-1 rounded-full text-[0.65rem] md:text-xs font-bold uppercase tracking-wide ${statusBadge(activity.statut)}`}>
                    {statusLabel(activity.statut)}
                  </span>
                </div>
                
                <p className="text-gray-600 text-sm mb-3 md:mb-4 line-clamp-2">{activity.desc}</p>
                
                <div className="flex flex-wrap gap-x-4 gap-y-2 text-xs md:text-sm text-gray-500">
                  <span className="flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5 md:w-4 md:h-4" />
                    {activity.date}
                  </span>
                  <span className="flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5 md:w-4 md:h-4" />
                    <span className="truncate max-w-[120px] sm:max-w-none">{activity.lieu}</span>
                  </span>
                  <span className="flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5 md:w-4 md:h-4" />
                    {chef ? `${chef.prenom} ${chef.nom}` : '—'}
                  </span>
                  <span className="flex items-center gap-1.5">
                    <Users className="w-3.5 h-3.5 md:w-4 md:h-4" />
                    {participants}/{activity.limite}
                  </span>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
