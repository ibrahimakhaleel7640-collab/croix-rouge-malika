import { useState, useEffect } from 'react';
import { useAuth } from '@/context/AuthContext';
import { useNotifications } from '@/components/Notifications';
import { DB, roleLabel, statusBadge, statusLabel, financeTypeBadge } from '@/data/db';
import type { User, Activity, Finance } from '@/types';
import { 
  LayoutDashboard, Users, Calendar, UserCircle, Star, 
  DollarSign, Shield, Settings, FileText, Download, 
  Plus, Search, Edit, Trash2, Eye, X, Menu,
  RefreshCw, CheckCircle
} from 'lucide-react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  LineElement,
  PointElement,
  Title,
  Tooltip,
  Legend,
  ArcElement
} from 'chart.js';
import { Bar } from 'react-chartjs-2';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  LineElement,
  PointElement,
  Title,
  Tooltip,
  Legend,
  ArcElement
);

export function AdminDashboard() {
  const { currentUser } = useAuth();
  const { showNotification } = useNotifications();
  const [activeTab, setActiveTab] = useState('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [kpiData, setKpiData] = useState({ vol: 0, act: 0, part: 0, cot: 0 });
  
  const [volModalOpen, setVolModalOpen] = useState(false);
  const [actModalOpen, setActModalOpen] = useState(false);
  const [partModalOpen, setPartModalOpen] = useState(false);
  const [finModalOpen, setFinModalOpen] = useState(false);
  const [adminModalOpen, setAdminModalOpen] = useState(false);
  const [viewActModalOpen, setViewActModalOpen] = useState(false);
  const [selectedActivity, setSelectedActivity] = useState<Activity | null>(null);
  
  const [editingVol, setEditingVol] = useState<User | null>(null);
  const [editingAct, setEditingAct] = useState<Activity | null>(null);
  
  const [volSearch, setVolSearch] = useState('');
  const [volStatusFilter, setVolStatusFilter] = useState('');
  const [actSearch, setActSearch] = useState('');
  const [actStatusFilter, setActStatusFilter] = useState('');
  const [partActFilter, setPartActFilter] = useState('');

  useEffect(() => {
    refreshDashboard();
  }, []);

  const refreshDashboard = () => {
    const vols = DB.users.filter(u => ['volontaire', 'chef_equipe'].includes(u.role)).length;
    const cotTotal = DB.finances.reduce((s, f) => s + f.montant, 0);
    setKpiData({
      vol: vols,
      act: DB.activities.length,
      part: DB.participants.length,
      cot: cotTotal
    });
  };

  const months = ['Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Juin', 'Juil', 'Aoû', 'Sep', 'Oct', 'Nov', 'Déc'];
  const actByMonth = Array(12).fill(0);
  const cotByMonth = Array(12).fill(0);
  
  DB.activities.forEach(a => {
    const m = new Date(a.date).getMonth();
    actByMonth[m]++;
  });
  
  DB.finances.forEach(f => {
    const m = new Date(f.date).getMonth();
    cotByMonth[m] += f.montant;
  });

  const chartData = {
    labels: months,
    datasets: [
      { label: 'Activités', data: actByMonth, backgroundColor: 'rgba(204,0,0,0.8)', borderRadius: 4 },
      { label: 'Cotisations (kFCFA)', data: cotByMonth.map(v => Math.round(v/1000)), backgroundColor: 'rgba(200,146,42,0.7)', borderRadius: 4, yAxisID: 'y1' }
    ]
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      y: { beginAtZero: true, grid: { color: 'rgba(0,0,0,0.05)' } },
      y1: { position: 'right' as const, beginAtZero: true, grid: { display: false } }
    },
    plugins: { legend: { labels: { font: { family: 'DM Sans', size: 11 } } } }
  };

  const volCounts: Record<number, number> = {};
  DB.participants.forEach(p => { volCounts[p.userId] = (volCounts[p.userId] || 0) + 1; });
  const topVols = Object.entries(volCounts).sort((a, b) => b[1] - a[1]).slice(0, 5);

  const leaderCounts: Record<number, number> = {};
  DB.activities.forEach(a => { if (a.chefId) leaderCounts[a.chefId] = (leaderCounts[a.chefId] || 0) + 1; });
  const topLeaders = Object.entries(leaderCounts).sort((a, b) => b[1] - a[1]).slice(0, 5);

  const recentItems = [
    ...DB.users.slice(-3).map(u => ({ text: `Nouvelle inscription : ${u.prenom} ${u.nom}`, time: u.created, type: 'user' })),
    ...DB.activities.slice(-2).map(a => ({ text: `Activité créée : ${a.nom}`, time: a.date, type: 'activity' })),
    ...DB.finances.slice(-2).map(f => {
      const u = DB.users.find(x => x.id === f.userId);
      return { text: `Paiement reçu : ${f.montant.toLocaleString()} FCFA de ${u?.prenom || '?'} ${u?.nom || ''}`, time: f.date, type: 'finance' };
    }),
  ].sort((a, b) => new Date(b.time).getTime() - new Date(a.time).getTime()).slice(0, 6);

  const sidebarItems = [
    { id: 'dashboard', icon: <LayoutDashboard className="w-5 h-5" />, label: "Vue d'ensemble", shortLabel: 'Dashboard' },
    { id: 'volunteers', icon: <Users className="w-5 h-5" />, label: 'Volontaires', badge: kpiData.vol, shortLabel: 'Volontaires' },
    { id: 'activities', icon: <Calendar className="w-5 h-5" />, label: 'Activités', badge: kpiData.act, shortLabel: 'Activités' },
    { id: 'participants', icon: <UserCircle className="w-5 h-5" />, label: 'Participants', shortLabel: 'Participants' },
    { id: 'teamleaders', icon: <Star className="w-5 h-5" />, label: "Chefs d'équipe", shortLabel: 'Leaders' },
    { id: 'finances', icon: <DollarSign className="w-5 h-5" />, label: 'Finances', badge: DB.finances.length, shortLabel: 'Finances' },
  ];

  if (currentUser?.role === 'super_admin') {
    sidebarItems.push(
      { id: 'admins', icon: <Shield className="w-5 h-5" />, label: 'Administrateurs', shortLabel: 'Admins' },
      { id: 'system', icon: <Settings className="w-5 h-5" />, label: 'Système', shortLabel: 'Système' }
    );
  }

  const handleSaveVolunteer = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    const formData = new FormData(form);
    
    const data = {
      prenom: formData.get('prenom') as string,
      nom: formData.get('nom') as string,
      email: formData.get('email') as string,
      tel: formData.get('tel') as string,
      role: formData.get('role') as 'volontaire' | 'chef_equipe' | 'admin',
      statut: formData.get('statut') as 'actif' | 'en-attente' | 'suspendu',
      competences: formData.get('competences') as string,
    };

    if (editingVol) {
      const idx = DB.users.findIndex(u => u.id === editingVol.id);
      if (idx !== -1) DB.users[idx] = { ...DB.users[idx], ...data };
      showNotification('success', 'Modifié !', `${data.prenom} ${data.nom} a été mis à jour.`);
    } else {
      DB.users.push({
        id: DB.nextId.users++,
        ...data,
        password: 'vol123',
        dob: '',
        adresse: 'Malika',
        experiences: '',
        cv: null,
        created: new Date().toISOString().split('T')[0]
      } as User);
      showNotification('success', 'Ajouté !', `${data.prenom} ${data.nom} a été créé.`);
    }
    
    setVolModalOpen(false);
    setEditingVol(null);
    refreshDashboard();
  };

  const handleDeleteVolunteer = (id: number) => {
    const u = DB.users.find(u => u.id === id);
    if (!u) return;
    if (confirm(`Supprimer ${u.prenom} ${u.nom} ?`)) {
      DB.users = DB.users.filter(u => u.id !== id);
      DB.participants = DB.participants.filter(p => p.userId !== id);
      showNotification('info', 'Supprimé', `${u.prenom} ${u.nom} a été supprimé.`);
      refreshDashboard();
    }
  };

  const handleSaveActivity = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    const formData = new FormData(form);
    
    const chefId = formData.get('chef') as string;
    const data = {
      nom: formData.get('nom') as string,
      desc: formData.get('desc') as string,
      date: formData.get('date') as string,
      lieu: formData.get('lieu') as string,
      statut: formData.get('statut') as 'prevue' | 'en-cours' | 'terminee',
      limite: parseInt(formData.get('limite') as string) || 50,
      chefId: chefId ? parseInt(chefId) : null,
    };

    if (editingAct) {
      const idx = DB.activities.findIndex(a => a.id === editingAct.id);
      if (idx !== -1) DB.activities[idx] = { ...DB.activities[idx], ...data };
      showNotification('success', 'Modifié !', `L'activité "${data.nom}" a été mise à jour.`);
    } else {
      DB.activities.push({
        id: DB.nextId.activities++,
        ...data,
        created: new Date().toISOString().split('T')[0]
      } as Activity);
      showNotification('success', 'Activité créée !', `"${data.nom}" programmée pour le ${data.date}.`);
    }
    
    setActModalOpen(false);
    setEditingAct(null);
    refreshDashboard();
  };

  const handleDeleteActivity = (id: number) => {
    const a = DB.activities.find(a => a.id === id);
    if (!a) return;
    if (confirm(`Supprimer l'activité "${a.nom}" ?`)) {
      DB.activities = DB.activities.filter(a => a.id !== id);
      DB.participants = DB.participants.filter(p => p.actId !== id);
      showNotification('info', 'Supprimée', `Activité "${a.nom}" supprimée.`);
      refreshDashboard();
    }
  };

  const handleViewActivity = (id: number) => {
    const a = DB.activities.find(a => a.id === id);
    if (a) {
      setSelectedActivity(a);
      setViewActModalOpen(true);
    }
  };

  const handleSaveFinance = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    const formData = new FormData(form);
    
    const montant = parseFloat(formData.get('montant') as string);
    if (!montant || montant <= 0) {
      showNotification('error', 'Erreur', 'Montant invalide.');
      return;
    }
    
    const actId = formData.get('activity') as string;
    DB.finances.push({
      id: DB.nextId.finances++,
      userId: parseInt(formData.get('volunteer') as string),
      montant,
      type: formData.get('type') as 'cotisation' | 'don' | 'frais_activite',
      mode: formData.get('mode') as 'cash' | 'wave' | 'orange_money' | 'free_money' | 'virement',
      ref: (formData.get('ref') as string) || 'TXN-' + Date.now(),
      date: formData.get('date') as string,
      actId: actId ? parseInt(actId) : null
    } as Finance);
    
    showNotification('success', 'Paiement enregistré !', `${montant.toLocaleString()} FCFA enregistré avec succès.`);
    setFinModalOpen(false);
    refreshDashboard();
  };

  const handleDeleteFinance = (id: number) => {
    if (confirm('Supprimer ce paiement ?')) {
      DB.finances = DB.finances.filter(f => f.id !== id);
      showNotification('info', 'Supprimé', 'Paiement supprimé.');
      refreshDashboard();
    }
  };

  const handleExport = (type: string) => {
    if (type === 'pdf') {
      showNotification('info', 'Export PDF', 'Génération du rapport PDF en cours...');
      setTimeout(() => showNotification('success', 'PDF généré !', 'Le rapport a été téléchargé.'), 1500);
    } else if (type === 'excel') {
      showNotification('info', 'Export Excel', 'Génération du fichier Excel en cours...');
      setTimeout(() => showNotification('success', 'Excel généré !', 'Le fichier Excel a été téléchargé.'), 1500);
    } else if (type === 'pdf-finance') {
      const total = DB.finances.reduce((s, f) => s + f.montant, 0);
      showNotification('info', 'Rapport financier', 'Génération en cours...');
      setTimeout(() => showNotification('success', 'Rapport financier prêt', `Total : ${total.toLocaleString()} FCFA`), 1500);
    }
  };

  const filteredVols = DB.users.filter(u => {
    if (!['volontaire', 'chef_equipe'].includes(u.role)) return false;
    const matchesSearch = volSearch === '' || `${u.prenom} ${u.nom} ${u.email}`.toLowerCase().includes(volSearch.toLowerCase());
    const matchesStatus = volStatusFilter === '' || u.statut === volStatusFilter;
    return matchesSearch && matchesStatus;
  });

  const filteredActs = DB.activities.filter(a => {
    const matchesSearch = actSearch === '' || `${a.nom} ${a.lieu}`.toLowerCase().includes(actSearch.toLowerCase());
    const matchesStatus = actStatusFilter === '' || a.statut === actStatusFilter;
    return matchesSearch && matchesStatus;
  });

  const finTotal = DB.finances.reduce((s, f) => s + f.montant, 0);
  const finCot = DB.finances.filter(f => f.type === 'cotisation').reduce((s, f) => s + f.montant, 0);
  const finDons = DB.finances.filter(f => f.type === 'don').reduce((s, f) => s + f.montant, 0);

  const filteredParts = partActFilter 
    ? DB.participants.filter(p => p.actId === parseInt(partActFilter))
    : DB.participants;

  // System stats
  const activeVols = DB.users.filter(u => ['volontaire', 'chef_equipe'].includes(u.role) && u.statut === 'actif').length;
  const totalVols = DB.users.filter(u => ['volontaire', 'chef_equipe'].includes(u.role)).length;
  const doneActs = DB.activities.filter(a => a.statut === 'terminee').length;
  const totalActs = DB.activities.length;
  const cotTarget = 200000;
  const cotProgress = Math.min((finTotal / cotTarget) * 100, 100);

  // Participant handlers
  const handleSaveParticipant = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    const formData = new FormData(form);
    
    const actId = parseInt(formData.get('activity') as string);
    const userId = parseInt(formData.get('volunteer') as string);
    const role = formData.get('role') as string;
    
    if (DB.participants.find(p => p.actId === actId && p.userId === userId)) {
      showNotification('error', 'Déjà assigné', 'Ce volontaire participe déjà à cette activité.');
      return;
    }
    
    DB.participants.push({
      id: DB.nextId.participants++,
      actId,
      userId,
      role,
      date: new Date().toISOString().split('T')[0]
    });
    
    showNotification('success', 'Participant assigné !', 'Le volontaire a été ajouté à l\'activité.');
    setPartModalOpen(false);
    refreshDashboard();
  };

  const handleDeleteParticipant = (id: number) => {
    if (confirm('Retirer ce participant ?')) {
      DB.participants = DB.participants.filter(p => p.id !== id);
      showNotification('info', 'Retiré', 'Participant retiré de l\'activité.');
      refreshDashboard();
    }
  };

  // Admin handlers
  const handleSaveAdmin = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    const formData = new FormData(form);
    
    const prenom = formData.get('prenom') as string;
    const nom = formData.get('nom') as string;
    const email = formData.get('email') as string;
    const password = formData.get('password') as string;
    const role = formData.get('role') as 'admin' | 'super_admin';
    
    if (!prenom || !nom || !email || !password) {
      showNotification('error', 'Erreur', 'Tous les champs sont requis.');
      return;
    }
    
    DB.admins.push({ id: DB.nextId.admins++, prenom, nom, email, role, lastAccess: 'Jamais' });
    DB.users.push({
      id: DB.nextId.users++,
      prenom, nom, email, password, tel: '', adresse: '', competences: '', experiences: '', role, statut: 'actif', dob: '', cv: null,
      created: new Date().toISOString().split('T')[0]
    } as User);
    
    showNotification('success', 'Admin créé !', `${prenom} ${nom} peut maintenant se connecter.`);
    setAdminModalOpen(false);
  };

  const handleDeleteAdmin = (id: number) => {
    const a = DB.admins.find(a => a.id === id);
    if (!a) return;
    if (confirm(`Supprimer l'administrateur ${a.prenom} ${a.nom} ?`)) {
      DB.admins = DB.admins.filter(a => a.id !== id);
      DB.users = DB.users.filter(u => u.email !== a.email);
      showNotification('info', 'Supprimé', `${a.prenom} ${a.nom} retiré des administrateurs.`);
    }
  };

  // Backup handler
  const handleBackup = () => {
    showNotification('info', 'Sauvegarde', 'Sauvegarde en cours...');
    setTimeout(() => {
      showNotification('success', 'Backup réussi', 'Base de données sauvegardée avec succès.');
    }, 2000);
  };

  if (!currentUser) return null;

  return (
    <div className="min-h-[calc(100vh-70px)] bg-[#FAF7F2]">
      {/* Mobile Header */}
      <div className="lg:hidden bg-white border-b border-gray-200 px-4 py-3 flex items-center justify-between sticky top-[70px] z-30">
        <button 
          onClick={() => setSidebarOpen(!sidebarOpen)}
          className="flex items-center gap-2 text-[#CC0000]"
        >
          <Menu className="w-6 h-6" />
          <span className="font-medium">Menu</span>
        </button>
        <span className="text-sm font-medium text-gray-600">
          {sidebarItems.find(i => i.id === activeTab)?.label}
        </span>
        <div className="w-8" />
      </div>

      {/* Sidebar - Desktop & Mobile */}
      <div className={`${sidebarOpen ? 'fixed inset-0 z-40 lg:static' : 'hidden lg:block'} lg:w-64`}>
        <div className="bg-[#1A1A1A] text-white h-full overflow-y-auto lg:fixed lg:w-64 lg:h-[calc(100vh-70px)]">
          <div className="px-4 pb-4 border-b border-white/10 mb-4 pt-4 lg:pt-0">
            <div className="flex lg:block items-center justify-between">
              <div>
                <div className="text-xs uppercase tracking-wider text-white/40 mb-1">Espace Admin</div>
                <div className="font-semibold text-sm lg:text-base">{currentUser.prenom} {currentUser.nom}</div>
              </div>
              <button onClick={() => setSidebarOpen(false)} className="lg:hidden p-2">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="mt-2">
              <span className={`px-2 py-1 rounded-full text-xs font-bold ${currentUser.role === 'super_admin' ? 'bg-gray-800' : 'bg-red-100 text-red-700'}`}>
                {roleLabel(currentUser.role)}
              </span>
            </div>
          </div>
          
          <div className="px-4 pb-4">
            <div className="text-xs uppercase tracking-wider text-white/40 mb-2">Tableau de bord</div>
            {sidebarItems.map(item => (
              <button
                key={item.id}
                onClick={() => { setActiveTab(item.id); setSidebarOpen(false); }}
                className={`w-full flex items-center gap-3 px-3 py-3 rounded-lg mb-1 transition-colors ${
                  activeTab === item.id ? 'bg-[#CC0000]' : 'hover:bg-white/10 text-white/70'
                }`}
              >
                {item.icon}
                <span className="text-sm font-medium flex-1 text-left hidden lg:inline">{item.label}</span>
                <span className="text-sm font-medium flex-1 text-left lg:hidden">{item.shortLabel}</span>
                {item.badge !== undefined && item.badge > 0 && (
                  <span className="bg-[#CC0000] text-white text-xs font-bold px-2 py-0.5 rounded-full">
                    {item.badge}
                  </span>
                )}
              </button>
            ))}
          </div>
          
          <div className="px-4 mt-2 pt-4 border-t border-white/10">
            <div className="text-xs uppercase tracking-wider text-white/40 mb-2">Export</div>
            <button onClick={() => handleExport('pdf')} className="w-full flex items-center gap-3 px-3 py-2 rounded-lg mb-1 hover:bg-white/10 text-white/70 transition-colors text-sm">
              <FileText className="w-4 h-4" /> <span className="hidden lg:inline">Export PDF</span>
            </button>
            <button onClick={() => handleExport('excel')} className="w-full flex items-center gap-3 px-3 py-2 rounded-lg mb-1 hover:bg-white/10 text-white/70 transition-colors text-sm">
              <Download className="w-4 h-4" /> <span className="hidden lg:inline">Export Excel</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="lg:ml-64 p-4 md:p-8">
        {/* Dashboard Tab */}
        {activeTab === 'dashboard' && (
          <div>
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6 md:mb-8">
              <div>
                <h2 className="font-serif text-xl md:text-2xl font-bold text-[#1A1A1A]">🏠 Tableau de bord</h2>
                <p className="text-gray-500 text-xs md:text-sm mt-1">
                  {new Date().toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
                </p>
              </div>
              <button onClick={refreshDashboard} className="flex items-center gap-2 px-3 md:px-4 py-2 border-2 border-[#CC0000] text-[#CC0000] rounded-lg hover:bg-red-50 transition-colors text-sm">
                <RefreshCw className="w-4 h-4" /> <span className="hidden sm:inline">Actualiser</span>
              </button>
            </div>

            {/* KPIs */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-5 mb-6 md:mb-8">
              {[
                { icon: <Users className="w-5 h-5 md:w-6 md:h-6" />, value: kpiData.vol, label: 'Volontaires', trend: '↑ actifs', color: 'border-l-[#CC0000]' },
                { icon: <Calendar className="w-5 h-5 md:w-6 md:h-6" />, value: kpiData.act, label: 'Activités', trend: '↑ programmées', color: 'border-l-[#C8922A]' },
                { icon: <UserCircle className="w-5 h-5 md:w-6 md:h-6" />, value: kpiData.part, label: 'Participations', trend: '↑ total', color: 'border-l-[#1A8A4A]' },
                { icon: <DollarSign className="w-5 h-5 md:w-6 md:h-6" />, value: kpiData.cot.toLocaleString(), label: 'FCFA', trend: '↑ cotisations', color: 'border-l-[#1D6FA4]' },
              ].map((kpi, i) => (
                <div key={i} className={`bg-white rounded-xl p-4 md:p-6 shadow-[0_4px_24px_rgba(0,0,0,0.08)] border-l-4 ${kpi.color}`}>
                  <div className="text-xl md:text-2xl mb-1 md:mb-2">{kpi.icon}</div>
                  <div className="font-serif text-xl md:text-3xl font-black text-[#1A1A1A]">{kpi.value}</div>
                  <div className="text-[0.6rem] md:text-xs text-gray-500 uppercase tracking-wide mt-0.5 md:mt-1">{kpi.label}</div>
                  <div className="text-[0.6rem] md:text-xs text-green-600 font-semibold mt-0.5 md:mt-1">{kpi.trend}</div>
                </div>
              ))}
            </div>

            {/* Charts */}
            <div className="grid lg:grid-cols-3 gap-4 md:gap-6 mb-6 md:mb-8">
              <div className="lg:col-span-2 bg-white rounded-xl p-4 md:p-6 shadow-[0_4px_24px_rgba(0,0,0,0.08)]">
                <h3 className="font-serif text-base md:text-lg font-bold mb-3 md:mb-4 flex items-center gap-2">
                  <LayoutDashboard className="w-4 md:w-5 h-4 md:h-5" />
                  Activités & Cotisations
                </h3>
                <div className="h-48 md:h-64">
                  <Bar data={chartData} options={chartOptions} />
                </div>
              </div>
              
              <div className="bg-white rounded-xl p-4 md:p-6 shadow-[0_4px_24px_rgba(0,0,0,0.08)]">
                <h3 className="font-serif text-base md:text-lg font-bold mb-3 md:mb-4 flex items-center gap-2">
                  <Star className="w-4 md:w-5 h-4 md:h-5" />
                  Top Volontaires
                </h3>
                <div className="space-y-2 md:space-y-3">
                  {topVols.map(([uid, cnt], idx) => {
                    const u = DB.users.find(u => u.id === parseInt(uid));
                    if (!u) return null;
                    const rankColors = ['bg-[#C8922A]', 'bg-gray-400', 'bg-[#C07A4E]', 'bg-gray-600', 'bg-gray-600'];
                    return (
                      <div key={uid} className="flex items-center gap-2 md:gap-3 p-2 md:p-3 bg-[#FAF7F2] rounded-lg">
                        <div className={`w-6 h-6 md:w-7 md:h-7 rounded-full ${rankColors[idx]} text-white flex items-center justify-center text-xs font-bold`}>
                          {idx + 1}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="font-semibold text-sm truncate">{u.prenom} {u.nom}</div>
                          <div className="text-xs text-gray-500">{roleLabel(u.role)}</div>
                        </div>
                        <div className="font-serif font-bold text-[#CC0000] text-sm">{cnt}</div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Recent Activity & Top Leaders */}
            <div className="grid md:grid-cols-2 gap-4 md:gap-6">
              <div className="bg-white rounded-xl p-4 md:p-6 shadow-[0_4px_24px_rgba(0,0,0,0.08)]">
                <h3 className="font-serif text-base md:text-lg font-bold mb-3 md:mb-4 flex items-center gap-2">
                  <CheckCircle className="w-4 md:w-5 h-4 md:h-5" />
                  Activités récentes
                </h3>
                <div className="space-y-2 md:space-y-3">
                  {recentItems.map((item, idx) => (
                    <div key={idx} className="flex gap-2 md:gap-3 p-2 md:p-3 bg-[#FAF7F2] rounded-lg">
                      <div className={`w-2 md:w-2.5 h-2 md:h-2.5 rounded-full mt-1 flex-shrink-0 ${
                        item.type === 'user' ? 'bg-[#CC0000]' : item.type === 'activity' ? 'bg-[#C8922A]' : 'bg-[#1A8A4A]'
                      }`} />
                      <div className="min-w-0">
                        <div className="text-xs md:text-sm truncate" dangerouslySetInnerHTML={{ __html: item.text }} />
                        <div className="text-[0.65rem] md:text-xs text-gray-500 mt-0.5">📅 {item.time}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="bg-white rounded-xl p-4 md:p-6 shadow-[0_4px_24px_rgba(0,0,0,0.08)]">
                <h3 className="font-serif text-base md:text-lg font-bold mb-3 md:mb-4 flex items-center gap-2">
                  <Star className="w-4 md:w-5 h-4 md:h-5" />
                  Chefs d'équipe
                </h3>
                <div className="space-y-2 md:space-y-3">
                  {topLeaders.map(([uid, cnt], idx) => {
                    const u = DB.users.find(u => u.id === parseInt(uid));
                    if (!u) return null;
                    const rankColors = ['bg-[#C8922A]', 'bg-gray-400', 'bg-[#C07A4E]', 'bg-gray-600', 'bg-gray-600'];
                    return (
                      <div key={uid} className="flex items-center gap-2 md:gap-3 p-2 md:p-3 bg-[#FAF7F2] rounded-lg">
                        <div className={`w-6 h-6 md:w-7 md:h-7 rounded-full ${rankColors[idx]} text-white flex items-center justify-center text-xs font-bold`}>
                          {idx + 1}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="font-semibold text-sm truncate">{u.prenom} {u.nom}</div>
                          <div className="text-xs text-gray-500">{u.competences?.split(',')[0] || 'Volontaire'}</div>
                        </div>
                        <div className="font-serif font-bold text-[#CC0000] text-sm">{cnt}</div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Volunteers Tab */}
        {activeTab === 'volunteers' && (
          <div>
            <h2 className="font-serif text-xl md:text-2xl font-bold text-[#1A1A1A] mb-4 md:mb-6">👥 Volontaires</h2>
            
            <div className="flex flex-col sm:flex-row gap-3 mb-4 md:mb-6">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  placeholder="Rechercher..."
                  value={volSearch}
                  onChange={(e) => setVolSearch(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 md:py-3 border-2 border-[#E8E4DF] rounded-lg focus:border-[#CC0000] focus:outline-none text-sm"
                />
              </div>
              <select
                value={volStatusFilter}
                onChange={(e) => setVolStatusFilter(e.target.value)}
                className="px-4 py-2.5 md:py-3 border-2 border-[#E8E4DF] rounded-lg focus:border-[#CC0000] focus:outline-none bg-white text-sm"
              >
                <option value="">Tous</option>
                <option value="actif">Actif</option>
                <option value="en-attente">En attente</option>
                <option value="suspendu">Suspendu</option>
              </select>
              <button
                onClick={() => { setEditingVol(null); setVolModalOpen(true); }}
                className="flex items-center justify-center gap-2 px-4 py-2.5 md:py-3 bg-[#CC0000] text-white rounded-lg hover:bg-[#990000] transition-colors text-sm"
              >
                <Plus className="w-5 h-5" /> <span className="hidden sm:inline">Ajouter</span>
              </button>
            </div>
            
            {/* Mobile Cards */}
            <div className="md:hidden space-y-3">
              {filteredVols.map((u) => {
                const parts = DB.participants.filter(p => p.userId === u.id).length;
                return (
                  <div key={u.id} className="bg-white rounded-xl p-4 shadow-[0_4px_24px_rgba(0,0,0,0.08)]">
                    <div className="flex justify-between items-start mb-2">
                      <div>
                        <div className="font-semibold">{u.prenom} {u.nom}</div>
                        <div className="text-xs text-gray-500">{u.email}</div>
                      </div>
                      <span className={`px-2 py-1 rounded-full text-[0.65rem] font-bold uppercase ${statusBadge(u.statut)}`}>
                        {u.statut}
                      </span>
                    </div>
                    <div className="text-xs text-gray-500 mb-3">{u.tel || '—'} · {parts} participations</div>
                    <div className="flex gap-2">
                      <button
                        onClick={() => { setEditingVol(u); setVolModalOpen(true); }}
                        className="flex-1 py-2 bg-blue-100 text-blue-700 rounded-lg text-sm font-medium"
                      >
                        Modifier
                      </button>
                      <button
                        onClick={() => handleDeleteVolunteer(u.id)}
                        className="flex-1 py-2 bg-red-100 text-red-700 rounded-lg text-sm font-medium"
                      >
                        Supprimer
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
            
            {/* Desktop Table */}
            <div className="hidden md:block bg-white rounded-xl shadow-[0_4px_24px_rgba(0,0,0,0.08)] overflow-hidden">
              <table className="w-full">
                <thead className="bg-[#FAF7F2]">
                  <tr>
                    <th className="px-6 py-4 text-left text-xs font-bold uppercase text-gray-500">Nom</th>
                    <th className="px-6 py-4 text-left text-xs font-bold uppercase text-gray-500">Email</th>
                    <th className="px-6 py-4 text-left text-xs font-bold uppercase text-gray-500">Rôle</th>
                    <th className="px-6 py-4 text-left text-xs font-bold uppercase text-gray-500">Statut</th>
                    <th className="px-6 py-4 text-left text-xs font-bold uppercase text-gray-500">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredVols.map((u) => (
                    <tr key={u.id} className="border-t border-[#E8E4DF] hover:bg-red-50">
                      <td className="px-6 py-4 font-semibold">{u.prenom} {u.nom}</td>
                      <td className="px-6 py-4">{u.email}</td>
                      <td className="px-6 py-4">
                        <span className="px-3 py-1 rounded-full text-xs font-bold uppercase bg-blue-100 text-blue-700">
                          {roleLabel(u.role)}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase ${statusBadge(u.statut)}`}>
                          {u.statut}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex gap-2">
                          <button onClick={() => { setEditingVol(u); setVolModalOpen(true); }} className="w-8 h-8 bg-blue-100 text-blue-700 rounded-lg flex items-center justify-center hover:bg-blue-700 hover:text-white">
                            <Edit className="w-4 h-4" />
                          </button>
                          <button onClick={() => handleDeleteVolunteer(u.id)} className="w-8 h-8 bg-red-100 text-red-700 rounded-lg flex items-center justify-center hover:bg-red-700 hover:text-white">
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Activities Tab */}
        {activeTab === 'activities' && (
          <div>
            <h2 className="font-serif text-xl md:text-2xl font-bold text-[#1A1A1A] mb-4 md:mb-6">📅 Activités</h2>
            
            <div className="flex flex-col sm:flex-row gap-3 mb-4 md:mb-6">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  placeholder="Rechercher..."
                  value={actSearch}
                  onChange={(e) => setActSearch(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 md:py-3 border-2 border-[#E8E4DF] rounded-lg focus:border-[#CC0000] focus:outline-none text-sm"
                />
              </div>
              <select
                value={actStatusFilter}
                onChange={(e) => setActStatusFilter(e.target.value)}
                className="px-4 py-2.5 md:py-3 border-2 border-[#E8E4DF] rounded-lg focus:border-[#CC0000] focus:outline-none bg-white text-sm"
              >
                <option value="">Tous</option>
                <option value="prevue">Prévue</option>
                <option value="en-cours">En cours</option>
                <option value="terminee">Terminée</option>
              </select>
              <button
                onClick={() => { setEditingAct(null); setActModalOpen(true); }}
                className="flex items-center justify-center gap-2 px-4 py-2.5 md:py-3 bg-[#CC0000] text-white rounded-lg hover:bg-[#990000] transition-colors text-sm"
              >
                <Plus className="w-5 h-5" /> <span className="hidden sm:inline">Nouvelle</span>
              </button>
            </div>
            
            {/* Mobile Cards */}
            <div className="md:hidden space-y-3">
              {filteredActs.map((a) => {
                const chef = DB.users.find(u => u.id === a.chefId);
                const parts = DB.participants.filter(p => p.actId === a.id).length;
                return (
                  <div key={a.id} className="bg-white rounded-xl p-4 shadow-[0_4px_24px_rgba(0,0,0,0.08)]">
                    <div className="flex justify-between items-start mb-2">
                      <div className="font-semibold text-sm">{a.nom}</div>
                      <span className={`px-2 py-1 rounded-full text-[0.65rem] font-bold uppercase ${statusBadge(a.statut)}`}>
                        {statusLabel(a.statut)}
                      </span>
                    </div>
                    <div className="text-xs text-gray-500 mb-1">📅 {a.date} · 📍 {a.lieu}</div>
                    <div className="text-xs text-gray-500 mb-3">👤 {chef ? `${chef.prenom} ${chef.nom}` : '—'} · {parts}/{a.limite} participants</div>
                    <div className="flex gap-2">
                      <button onClick={() => handleViewActivity(a.id)} className="flex-1 py-2 bg-green-100 text-green-700 rounded-lg text-sm font-medium">Voir</button>
                      <button onClick={() => { setEditingAct(a); setActModalOpen(true); }} className="flex-1 py-2 bg-blue-100 text-blue-700 rounded-lg text-sm font-medium">Modifier</button>
                      <button onClick={() => handleDeleteActivity(a.id)} className="flex-1 py-2 bg-red-100 text-red-700 rounded-lg text-sm font-medium">Supprimer</button>
                    </div>
                  </div>
                );
              })}
            </div>
            
            {/* Desktop Table */}
            <div className="hidden md:block bg-white rounded-xl shadow-[0_4px_24px_rgba(0,0,0,0.08)] overflow-hidden">
              <table className="w-full">
                <thead className="bg-[#FAF7F2]">
                  <tr>
                    <th className="px-6 py-4 text-left text-xs font-bold uppercase text-gray-500">Nom</th>
                    <th className="px-6 py-4 text-left text-xs font-bold uppercase text-gray-500">Date</th>
                    <th className="px-6 py-4 text-left text-xs font-bold uppercase text-gray-500">Statut</th>
                    <th className="px-6 py-4 text-left text-xs font-bold uppercase text-gray-500">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredActs.map((a) => (
                    <tr key={a.id} className="border-t border-[#E8E4DF] hover:bg-red-50">
                      <td className="px-6 py-4 font-semibold">{a.nom}</td>
                      <td className="px-6 py-4">{a.date}</td>
                      <td className="px-6 py-4">
                        <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase ${statusBadge(a.statut)}`}>
                          {statusLabel(a.statut)}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex gap-2">
                          <button onClick={() => handleViewActivity(a.id)} className="w-8 h-8 bg-green-100 text-green-700 rounded-lg flex items-center justify-center hover:bg-green-700 hover:text-white"><Eye className="w-4 h-4" /></button>
                          <button onClick={() => { setEditingAct(a); setActModalOpen(true); }} className="w-8 h-8 bg-blue-100 text-blue-700 rounded-lg flex items-center justify-center hover:bg-blue-700 hover:text-white"><Edit className="w-4 h-4" /></button>
                          <button onClick={() => handleDeleteActivity(a.id)} className="w-8 h-8 bg-red-100 text-red-700 rounded-lg flex items-center justify-center hover:bg-red-700 hover:text-white"><Trash2 className="w-4 h-4" /></button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Finances Tab */}
        {activeTab === 'finances' && (
          <div>
            <h2 className="font-serif text-xl md:text-2xl font-bold text-[#1A1A1A] mb-4 md:mb-6">💰 Finances</h2>
            
            <div className="grid grid-cols-3 gap-2 md:gap-6 mb-6 md:mb-8">
              <div className="bg-white rounded-xl p-3 md:p-6 shadow-[0_4px_24px_rgba(0,0,0,0.08)] text-center">
                <div className="font-serif text-sm md:text-3xl font-black text-[#1A8A4A]">{finTotal.toLocaleString()}</div>
                <div className="text-[0.6rem] md:text-xs text-gray-500 uppercase mt-1">Total</div>
              </div>
              <div className="bg-white rounded-xl p-3 md:p-6 shadow-[0_4px_24px_rgba(0,0,0,0.08)] text-center">
                <div className="font-serif text-sm md:text-3xl font-black text-[#1A1A1A]">{finCot.toLocaleString()}</div>
                <div className="text-[0.6rem] md:text-xs text-gray-500 uppercase mt-1">Cotisations</div>
              </div>
              <div className="bg-white rounded-xl p-3 md:p-6 shadow-[0_4px_24px_rgba(0,0,0,0.08)] text-center">
                <div className="font-serif text-sm md:text-3xl font-black text-[#CC0000]">{finDons.toLocaleString()}</div>
                <div className="text-[0.6rem] md:text-xs text-gray-500 uppercase mt-1">Dons</div>
              </div>
            </div>
            
            <div className="flex justify-end mb-4">
              <button onClick={() => setFinModalOpen(true)} className="flex items-center gap-2 px-4 py-2.5 bg-[#CC0000] text-white rounded-lg hover:bg-[#990000] transition-colors text-sm">
                <Plus className="w-4 h-4" /> Ajouter
              </button>
            </div>
            
            {/* Mobile Cards */}
            <div className="md:hidden space-y-3">
              {DB.finances.map((f) => {
                const u = DB.users.find(u => u.id === f.userId);
                return (
                  <div key={f.id} className="bg-white rounded-xl p-4 shadow-[0_4px_24px_rgba(0,0,0,0.08)]">
                    <div className="flex justify-between items-start mb-2">
                      <span className="font-bold text-[#CC0000]">{f.montant.toLocaleString()} FCFA</span>
                      <span className={`px-2 py-1 rounded-full text-[0.65rem] font-bold uppercase ${financeTypeBadge(f.type)}`}>
                        {f.type}
                      </span>
                    </div>
                    <div className="text-xs text-gray-500 mb-1">{u ? `${u.prenom} ${u.nom}` : '?'}</div>
                    <div className="text-xs text-gray-500 mb-3">{f.mode} · {f.date}</div>
                    <button onClick={() => handleDeleteFinance(f.id)} className="w-full py-2 bg-red-100 text-red-700 rounded-lg text-sm font-medium">
                      Supprimer
                    </button>
                  </div>
                );
              })}
            </div>
            
            {/* Desktop Table */}
            <div className="hidden md:block bg-white rounded-xl shadow-[0_4px_24px_rgba(0,0,0,0.08)] overflow-hidden">
              <table className="w-full">
                <thead className="bg-[#FAF7F2]">
                  <tr>
                    <th className="px-6 py-4 text-left text-xs font-bold uppercase text-gray-500">Volontaire</th>
                    <th className="px-6 py-4 text-left text-xs font-bold uppercase text-gray-500">Montant</th>
                    <th className="px-6 py-4 text-left text-xs font-bold uppercase text-gray-500">Type</th>
                    <th className="px-6 py-4 text-left text-xs font-bold uppercase text-gray-500">Date</th>
                    <th className="px-6 py-4 text-left text-xs font-bold uppercase text-gray-500">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {DB.finances.map((f) => {
                    const u = DB.users.find(u => u.id === f.userId);
                    return (
                      <tr key={f.id} className="border-t border-[#E8E4DF] hover:bg-red-50">
                        <td className="px-6 py-4">{u ? `${u.prenom} ${u.nom}` : '?'}</td>
                        <td className="px-6 py-4 font-bold">{f.montant.toLocaleString()} FCFA</td>
                        <td className="px-6 py-4">
                          <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase ${financeTypeBadge(f.type)}`}>
                            {f.type}
                          </span>
                        </td>
                        <td className="px-6 py-4">{f.date}</td>
                        <td className="px-6 py-4">
                          <button onClick={() => handleDeleteFinance(f.id)} className="w-8 h-8 bg-red-100 text-red-700 rounded-lg flex items-center justify-center hover:bg-red-700 hover:text-white">
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Participants Tab */}
        {activeTab === 'participants' && (
          <div>
            <h2 className="font-serif text-xl md:text-2xl font-bold text-[#1A1A1A] mb-4 md:mb-6">👤 Participants</h2>
            
            <div className="flex flex-col sm:flex-row gap-3 mb-4 md:mb-6">
              <select
                value={partActFilter}
                onChange={(e) => setPartActFilter(e.target.value)}
                className="px-4 py-2.5 md:py-3 border-2 border-[#E8E4DF] rounded-lg focus:border-[#CC0000] focus:outline-none bg-white text-sm"
              >
                <option value="">Toutes les activités</option>
                {DB.activities.map(a => (
                  <option key={a.id} value={a.id}>{a.nom}</option>
                ))}
              </select>
              <button
                onClick={() => setPartModalOpen(true)}
                className="flex items-center justify-center gap-2 px-4 py-2.5 md:py-3 bg-[#CC0000] text-white rounded-lg hover:bg-[#990000] transition-colors text-sm"
              >
                <Plus className="w-5 h-5" /> <span className="hidden sm:inline">Assigner</span>
              </button>
            </div>
            
            {/* Mobile Cards */}
            <div className="md:hidden space-y-3">
              {filteredParts.map((p) => {
                const u = DB.users.find(u => u.id === p.userId);
                const a = DB.activities.find(a => a.id === p.actId);
                return (
                  <div key={p.id} className="bg-white rounded-xl p-4 shadow-[0_4px_24px_rgba(0,0,0,0.08)]">
                    <div className="font-semibold text-sm mb-1">{u ? `${u.prenom} ${u.nom}` : '?'}</div>
                    <div className="text-xs text-gray-500 mb-1">📅 {a?.nom || '?'}</div>
                    <div className="text-xs text-gray-500 mb-3">{p.date} · 
                      <span className="px-2 py-0.5 rounded-full text-[0.65rem] font-bold uppercase bg-blue-100 text-blue-700 ml-1">
                        {p.role}
                      </span>
                    </div>
                    <button 
                      onClick={() => handleDeleteParticipant(p.id)}
                      className="w-full py-2 bg-red-100 text-red-700 rounded-lg text-sm font-medium"
                    >
                      Retirer
                    </button>
                  </div>
                );
              })}
            </div>
            
            {/* Desktop Table */}
            <div className="hidden md:block bg-white rounded-xl shadow-[0_4px_24px_rgba(0,0,0,0.08)] overflow-hidden">
              <table className="w-full">
                <thead className="bg-[#FAF7F2]">
                  <tr>
                    <th className="px-6 py-4 text-left text-xs font-bold uppercase text-gray-500">Volontaire</th>
                    <th className="px-6 py-4 text-left text-xs font-bold uppercase text-gray-500">Activité</th>
                    <th className="px-6 py-4 text-left text-xs font-bold uppercase text-gray-500">Date</th>
                    <th className="px-6 py-4 text-left text-xs font-bold uppercase text-gray-500">Rôle</th>
                    <th className="px-6 py-4 text-left text-xs font-bold uppercase text-gray-500">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredParts.map((p) => {
                    const u = DB.users.find(u => u.id === p.userId);
                    const a = DB.activities.find(a => a.id === p.actId);
                    return (
                      <tr key={p.id} className="border-t border-[#E8E4DF] hover:bg-red-50">
                        <td className="px-6 py-4 font-semibold">{u ? `${u.prenom} ${u.nom}` : '?'}</td>
                        <td className="px-6 py-4">{a?.nom || '?'}</td>
                        <td className="px-6 py-4">{p.date}</td>
                        <td className="px-6 py-4">
                          <span className="px-3 py-1 rounded-full text-xs font-bold uppercase bg-blue-100 text-blue-700">
                            {p.role}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <button 
                            onClick={() => handleDeleteParticipant(p.id)}
                            className="w-8 h-8 bg-red-100 text-red-700 rounded-lg flex items-center justify-center hover:bg-red-700 hover:text-white"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Team Leaders Tab */}
        {activeTab === 'teamleaders' && (
          <div>
            <h2 className="font-serif text-xl md:text-2xl font-bold text-[#1A1A1A] mb-4 md:mb-6">⭐ Chefs d'Équipe</h2>
            
            <div className="bg-white rounded-xl p-4 md:p-6 shadow-[0_4px_24px_rgba(0,0,0,0.08)] mb-6">
              <h3 className="font-serif text-base md:text-lg font-bold mb-4">Classement par performance</h3>
              
              {/* Mobile Cards */}
              <div className="md:hidden space-y-3">
                {topLeaders.map(([uid, cnt], idx) => {
                  const u = DB.users.find(u => u.id === parseInt(uid));
                  if (!u) return null;
                  const rankColors = ['bg-amber-100 text-amber-700', 'bg-gray-100 text-gray-700', 'bg-gray-800 text-white', 'bg-gray-100 text-gray-600', 'bg-gray-100 text-gray-600'];
                  return (
                    <div key={uid} className="flex items-center gap-3 p-3 bg-[#FAF7F2] rounded-lg">
                      <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase ${rankColors[idx] || 'bg-gray-100'}`}>
                        #{idx + 1}
                      </span>
                      <div className="flex-1 min-w-0">
                        <div className="font-semibold text-sm truncate">{u.prenom} {u.nom}</div>
                        <div className="text-xs text-gray-500">{u.competences?.split(',')[0] || 'Volontaire'}</div>
                      </div>
                      <div className="text-right">
                        <div className="font-serif font-bold text-[#CC0000]">{cnt}</div>
                        <div className="text-[0.6rem] text-gray-500">activités</div>
                      </div>
                    </div>
                  );
                })}
              </div>
              
              {/* Desktop Table */}
              <div className="hidden md:block overflow-hidden">
                <table className="w-full">
                  <thead className="bg-[#FAF7F2]">
                    <tr>
                      <th className="px-6 py-4 text-left text-xs font-bold uppercase text-gray-500">Rang</th>
                      <th className="px-6 py-4 text-left text-xs font-bold uppercase text-gray-500">Chef d'équipe</th>
                      <th className="px-6 py-4 text-left text-xs font-bold uppercase text-gray-500">Email</th>
                      <th className="px-6 py-4 text-left text-xs font-bold uppercase text-gray-500">Activités</th>
                      <th className="px-6 py-4 text-left text-xs font-bold uppercase text-gray-500">Score</th>
                    </tr>
                  </thead>
                  <tbody>
                    {topLeaders.map(([uid, cnt], idx) => {
                      const u = DB.users.find(u => u.id === parseInt(uid));
                      if (!u) return null;
                      const max = topLeaders[0]?.[1] || 1;
                      const score = Math.round((cnt / max) * 100);
                      return (
                        <tr key={uid} className="border-t border-[#E8E4DF] hover:bg-red-50">
                          <td className="px-6 py-4">
                            <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase ${
                              idx === 0 ? 'bg-amber-100 text-amber-700' :
                              idx === 1 ? 'bg-gray-100 text-gray-700' :
                              idx === 2 ? 'bg-gray-800 text-white' :
                              'bg-gray-100 text-gray-600'
                            }`}>
                              {idx + 1}
                            </span>
                          </td>
                          <td className="px-6 py-4 font-semibold">{u.prenom} {u.nom}</td>
                          <td className="px-6 py-4">{u.email}</td>
                          <td className="px-6 py-4 font-bold">{cnt}</td>
                          <td className="px-6 py-4">
                            <div className="flex items-center gap-3">
                              <div className="flex-1 h-1.5 bg-gray-200 rounded-full overflow-hidden max-w-[100px]">
                                <div className="h-full bg-[#CC0000] rounded-full" style={{ width: `${score}%` }} />
                              </div>
                              <span className="text-sm font-semibold">{score}%</span>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
            
            {/* Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-6">
              <div className="bg-white rounded-xl p-4 shadow-[0_4px_24px_rgba(0,0,0,0.08)] text-center">
                <div className="font-serif text-2xl md:text-3xl font-black text-[#CC0000]">{topLeaders.length}</div>
                <div className="text-[0.6rem] md:text-xs text-gray-500 uppercase mt-1">Chefs actifs</div>
              </div>
              <div className="bg-white rounded-xl p-4 shadow-[0_4px_24px_rgba(0,0,0,0.08)] text-center">
                <div className="font-serif text-2xl md:text-3xl font-black text-[#C8922A]">
                  {topLeaders[0] ? topLeaders[0][1] : 0}
                </div>
                <div className="text-[0.6rem] md:text-xs text-gray-500 uppercase mt-1">Record activités</div>
              </div>
            </div>
          </div>
        )}

        {/* Admins Tab */}
        {activeTab === 'admins' && (
          <div>
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-4 md:mb-6">
              <div>
                <h2 className="font-serif text-xl md:text-2xl font-bold text-[#1A1A1A]">🛡️ Administrateurs</h2>
                <p className="text-gray-500 text-xs md:text-sm mt-1">Gestion des accès administrateurs</p>
              </div>
              {currentUser?.role === 'super_admin' && (
                <button
                  onClick={() => setAdminModalOpen(true)}
                  className="flex items-center gap-2 px-4 py-2.5 bg-[#CC0000] text-white rounded-lg hover:bg-[#990000] transition-colors text-sm"
                >
                  <Plus className="w-4 h-4" /> Ajouter
                </button>
              )}
            </div>
            
            {/* Mobile Cards */}
            <div className="md:hidden space-y-3">
              {DB.admins.map((a) => (
                <div key={a.id} className="bg-white rounded-xl p-4 shadow-[0_4px_24px_rgba(0,0,0,0.08)]">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <div className="font-semibold text-sm">{a.prenom} {a.nom}</div>
                      <div className="text-xs text-gray-500">{a.email}</div>
                    </div>
                    <span className={`px-2 py-1 rounded-full text-[0.65rem] font-bold uppercase ${
                      a.role === 'super_admin' ? 'bg-gray-800 text-white' : 'bg-red-100 text-red-700'
                    }`}>
                      {roleLabel(a.role)}
                    </span>
                  </div>
                  <div className="text-xs text-gray-500 mb-3">Dernier accès: {a.lastAccess}</div>
                  {currentUser?.role === 'super_admin' && a.email !== currentUser?.email && (
                    <button 
                      onClick={() => handleDeleteAdmin(a.id)}
                      className="w-full py-2 bg-red-100 text-red-700 rounded-lg text-sm font-medium"
                    >
                      Supprimer
                    </button>
                  )}
                </div>
              ))}
            </div>
            
            {/* Desktop Table */}
            <div className="hidden md:block bg-white rounded-xl shadow-[0_4px_24px_rgba(0,0,0,0.08)] overflow-hidden">
              <table className="w-full">
                <thead className="bg-[#FAF7F2]">
                  <tr>
                    <th className="px-6 py-4 text-left text-xs font-bold uppercase text-gray-500">Nom</th>
                    <th className="px-6 py-4 text-left text-xs font-bold uppercase text-gray-500">Email</th>
                    <th className="px-6 py-4 text-left text-xs font-bold uppercase text-gray-500">Rôle</th>
                    <th className="px-6 py-4 text-left text-xs font-bold uppercase text-gray-500">Dernier accès</th>
                    {currentUser?.role === 'super_admin' && <th className="px-6 py-4 text-left text-xs font-bold uppercase text-gray-500">Actions</th>}
                  </tr>
                </thead>
                <tbody>
                  {DB.admins.map((a) => (
                    <tr key={a.id} className="border-t border-[#E8E4DF] hover:bg-red-50">
                      <td className="px-6 py-4 font-semibold">{a.prenom} {a.nom}</td>
                      <td className="px-6 py-4">{a.email}</td>
                      <td className="px-6 py-4">
                        <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase ${
                          a.role === 'super_admin' ? 'bg-gray-800 text-white' : 'bg-red-100 text-red-700'
                        }`}>
                          {roleLabel(a.role)}
                        </span>
                      </td>
                      <td className="px-6 py-4">{a.lastAccess}</td>
                      {currentUser?.role === 'super_admin' && (
                        <td className="px-6 py-4">
                          {a.email !== currentUser?.email && (
                            <button 
                              onClick={() => handleDeleteAdmin(a.id)}
                              className="w-8 h-8 bg-red-100 text-red-700 rounded-lg flex items-center justify-center hover:bg-red-700 hover:text-white"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </td>
                      )}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* System Tab */}
        {activeTab === 'system' && (
          <div>
            <h2 className="font-serif text-xl md:text-2xl font-bold text-[#1A1A1A] mb-4 md:mb-6">⚙️ Système</h2>
            
            <div className="grid md:grid-cols-2 gap-4 md:gap-6 mb-6">
              {/* Backup Card */}
              <div className="bg-white rounded-xl p-4 md:p-6 shadow-[0_4px_24px_rgba(0,0,0,0.08)]">
                <h3 className="font-serif text-base md:text-lg font-bold mb-3 flex items-center gap-2">
                  <Download className="w-5 h-5" />
                  Sauvegarde
                </h3>
                <p className="text-gray-600 text-sm mb-4">Backup automatique toutes les 24h.</p>
                <div className="bg-blue-50 border border-blue-200 text-blue-700 px-3 py-2 rounded-lg mb-4 text-sm">
                  💾 Dernière sauvegarde : il y a 2h 30min
                </div>
                <button
                  onClick={handleBackup}
                  className="w-full py-3 bg-[#CC0000] text-white rounded-lg font-medium hover:bg-[#990000] transition-colors text-sm"
                >
                  Sauvegarder maintenant
                </button>
              </div>
              
              {/* Stats Card */}
              <div className="bg-white rounded-xl p-4 md:p-6 shadow-[0_4px_24px_rgba(0,0,0,0.08)]">
                <h3 className="font-serif text-base md:text-lg font-bold mb-4">📊 Statistiques</h3>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Volontaires actifs</span>
                      <span>{activeVols}/{totalVols}</span>
                    </div>
                    <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                      <div className="h-full bg-[#CC0000] rounded-full transition-all" style={{ width: `${totalVols ? (activeVols/totalVols)*100 : 0}%` }} />
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Activités terminées</span>
                      <span>{doneActs}/{totalActs}</span>
                    </div>
                    <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                      <div className="h-full bg-[#C8922A] rounded-full transition-all" style={{ width: `${totalActs ? (doneActs/totalActs)*100 : 0}%` }} />
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Taux de collecte</span>
                      <span>{Math.round(cotProgress)}%</span>
                    </div>
                    <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                      <div className="h-full bg-[#1A8A4A] rounded-full transition-all" style={{ width: `${cotProgress}%` }} />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Database Schema */}
            <div className="bg-white rounded-xl p-4 md:p-6 shadow-[0_4px_24px_rgba(0,0,0,0.08)]">
              <h3 className="font-serif text-base md:text-lg font-bold mb-4">🗄️ Schéma de la base de données</h3>
              <div className="bg-[#1A1A1A] text-gray-300 rounded-lg p-4 font-mono text-[0.65rem] md:text-xs overflow-x-auto">
                <pre>{`-- PostgreSQL - Croix-Rouge Malika
CREATE TABLE utilisateurs (
  id SERIAL PRIMARY KEY,
  prenom VARCHAR(100),
  nom VARCHAR(100),
  email VARCHAR(255) UNIQUE,
  role VARCHAR(50),
  statut VARCHAR(20),
  created_at TIMESTAMP
);

CREATE TABLE activites (
  id SERIAL PRIMARY KEY,
  nom VARCHAR(200),
  date_activite DATE,
  statut VARCHAR(20),
  chef_equipe_id INT
);

CREATE TABLE participants (
  id SERIAL PRIMARY KEY,
  utilisateur_id INT,
  activite_id INT,
  role_participation VARCHAR(50)
);

CREATE TABLE cotisations (
  id SERIAL PRIMARY KEY,
  utilisateur_id INT,
  montant DECIMAL(10,2),
  type VARCHAR(50),
  date_paiement DATE
);`}</pre>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Modals */}
      {volModalOpen && (
        <Modal title={editingVol ? 'Modifier volontaire' : 'Ajouter volontaire'} onClose={() => setVolModalOpen(false)}>
          <form onSubmit={handleSaveVolunteer} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <input name="prenom" defaultValue={editingVol?.prenom} placeholder="Prénom" required className="input-mobile" />
              <input name="nom" defaultValue={editingVol?.nom} placeholder="Nom" required className="input-mobile" />
            </div>
            <input name="email" type="email" defaultValue={editingVol?.email} placeholder="Email" required className="input-mobile" />
            <input name="tel" defaultValue={editingVol?.tel} placeholder="Téléphone" className="input-mobile" />
            <div className="grid grid-cols-2 gap-4">
              <select name="role" defaultValue={editingVol?.role || 'volontaire'} className="input-mobile">
                <option value="volontaire">Volontaire</option>
                <option value="chef_equipe">Chef d'équipe</option>
              </select>
              <select name="statut" defaultValue={editingVol?.statut || 'actif'} className="input-mobile">
                <option value="actif">Actif</option>
                <option value="en-attente">En attente</option>
                <option value="suspendu">Suspendu</option>
              </select>
            </div>
            <input name="competences" defaultValue={editingVol?.competences} placeholder="Compétences" className="input-mobile" />
            <div className="flex gap-3 pt-2">
              <button type="button" onClick={() => setVolModalOpen(false)} className="flex-1 py-3 bg-gray-100 rounded-lg text-sm font-medium">Annuler</button>
              <button type="submit" className="flex-1 py-3 bg-[#CC0000] text-white rounded-lg text-sm font-medium">Sauvegarder</button>
            </div>
          </form>
        </Modal>
      )}

      {actModalOpen && (
        <Modal title={editingAct ? "Modifier l'activité" : 'Nouvelle activité'} onClose={() => setActModalOpen(false)}>
          <form onSubmit={handleSaveActivity} className="space-y-4">
            <input name="nom" defaultValue={editingAct?.nom} placeholder="Nom de l'activité" required className="input-mobile" />
            <textarea name="desc" defaultValue={editingAct?.desc} placeholder="Description" rows={3} className="input-mobile resize-none" />
            <div className="grid grid-cols-2 gap-4">
              <input name="date" type="date" defaultValue={editingAct?.date} required className="input-mobile" />
              <input name="lieu" defaultValue={editingAct?.lieu} placeholder="Lieu" className="input-mobile" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <select name="statut" defaultValue={editingAct?.statut || 'prevue'} className="input-mobile">
                <option value="prevue">Prévue</option>
                <option value="en-cours">En cours</option>
                <option value="terminee">Terminée</option>
              </select>
              <input name="limite" type="number" defaultValue={editingAct?.limite || 50} placeholder="Limite" className="input-mobile" />
            </div>
            <select name="chef" defaultValue={editingAct?.chefId || ''} className="input-mobile">
              <option value="">— Chef d'équipe —</option>
              {DB.users.map(u => <option key={u.id} value={u.id}>{u.prenom} {u.nom}</option>)}
            </select>
            <div className="flex gap-3 pt-2">
              <button type="button" onClick={() => setActModalOpen(false)} className="flex-1 py-3 bg-gray-100 rounded-lg text-sm font-medium">Annuler</button>
              <button type="submit" className="flex-1 py-3 bg-[#CC0000] text-white rounded-lg text-sm font-medium">Sauvegarder</button>
            </div>
          </form>
        </Modal>
      )}

      {finModalOpen && (
        <Modal title="Enregistrer un paiement" onClose={() => setFinModalOpen(false)}>
          <form onSubmit={handleSaveFinance} className="space-y-4">
            <select name="volunteer" required className="input-mobile">
              {DB.users.map(u => <option key={u.id} value={u.id}>{u.prenom} {u.nom}</option>)}
            </select>
            <div className="grid grid-cols-2 gap-4">
              <input name="montant" type="number" placeholder="Montant (FCFA)" required className="input-mobile" />
              <input name="date" type="date" defaultValue={new Date().toISOString().split('T')[0]} required className="input-mobile" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <select name="type" className="input-mobile">
                <option value="cotisation">Cotisation</option>
                <option value="don">Don</option>
                <option value="frais_activite">Frais d'activité</option>
              </select>
              <select name="mode" className="input-mobile">
                <option value="cash">Cash</option>
                <option value="wave">Wave</option>
                <option value="orange_money">Orange Money</option>
                <option value="free_money">Free Money</option>
              </select>
            </div>
            <div className="flex gap-3 pt-2">
              <button type="button" onClick={() => setFinModalOpen(false)} className="flex-1 py-3 bg-gray-100 rounded-lg text-sm font-medium">Annuler</button>
              <button type="submit" className="flex-1 py-3 bg-[#1A8A4A] text-white rounded-lg text-sm font-medium">Enregistrer</button>
            </div>
          </form>
        </Modal>
      )}

      {viewActModalOpen && selectedActivity && (
        <Modal title={selectedActivity.nom} onClose={() => setViewActModalOpen(false)}>
          {(() => {
            const chef = DB.users.find(u => u.id === selectedActivity.chefId);
            const parts = DB.participants.filter(p => p.actId === selectedActivity.id);
            return (
              <div className="space-y-3">
                <div className="text-sm"><strong>Date:</strong> {selectedActivity.date}</div>
                <div className="text-sm"><strong>Lieu:</strong> {selectedActivity.lieu}</div>
                <div className="text-sm"><strong>Statut:</strong> <span className={`px-2 py-1 rounded-full text-xs font-bold uppercase ${statusBadge(selectedActivity.statut)}`}>{statusLabel(selectedActivity.statut)}</span></div>
                <div className="text-sm"><strong>Chef d'équipe:</strong> {chef ? `${chef.prenom} ${chef.nom}` : '—'}</div>
                <div className="text-sm"><strong>Participants:</strong> {parts.length}/{selectedActivity.limite}</div>
                <div className="text-sm"><strong>Description:</strong> {selectedActivity.desc}</div>
              </div>
            );
          })()}
        </Modal>
      )}

      {partModalOpen && (
        <Modal title="Assigner un participant" onClose={() => setPartModalOpen(false)}>
          <form onSubmit={handleSaveParticipant} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wide mb-2">Activité *</label>
              <select name="activity" required className="input-mobile">
                {DB.activities.map(a => (
                  <option key={a.id} value={a.id}>{a.nom}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wide mb-2">Volontaire *</label>
              <select name="volunteer" required className="input-mobile">
                {DB.users.filter(u => ['volontaire', 'chef_equipe'].includes(u.role)).map(u => (
                  <option key={u.id} value={u.id}>{u.prenom} {u.nom}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wide mb-2">Rôle</label>
              <select name="role" className="input-mobile">
                <option value="participant">Participant</option>
                <option value="responsable">Responsable</option>
                <option value="observateur">Observateur</option>
              </select>
            </div>
            <div className="flex gap-3 pt-2">
              <button type="button" onClick={() => setPartModalOpen(false)} className="flex-1 py-3 bg-gray-100 rounded-lg text-sm font-medium">Annuler</button>
              <button type="submit" className="flex-1 py-3 bg-[#CC0000] text-white rounded-lg text-sm font-medium">Assigner</button>
            </div>
          </form>
        </Modal>
      )}

      {adminModalOpen && (
        <Modal title="Ajouter un administrateur" onClose={() => setAdminModalOpen(false)}>
          <form onSubmit={handleSaveAdmin} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <input name="prenom" placeholder="Prénom" required className="input-mobile" />
              <input name="nom" placeholder="Nom" required className="input-mobile" />
            </div>
            <input name="email" type="email" placeholder="Email" required className="input-mobile" />
            <input name="password" type="password" placeholder="Mot de passe" required className="input-mobile" />
            <select name="role" className="input-mobile">
              <option value="admin">Admin</option>
              <option value="super_admin">Super Admin</option>
            </select>
            <div className="flex gap-3 pt-2">
              <button type="button" onClick={() => setAdminModalOpen(false)} className="flex-1 py-3 bg-gray-100 rounded-lg text-sm font-medium">Annuler</button>
              <button type="submit" className="flex-1 py-3 bg-[#CC0000] text-white rounded-lg text-sm font-medium">Créer</button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}

// Modal Component
function Modal({ title, children, onClose }: { title: string; children: React.ReactNode; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="absolute inset-0 bg-black/50" onClick={onClose} />
      <div className="relative bg-white rounded-t-2xl sm:rounded-2xl w-full sm:max-w-lg max-h-[90vh] overflow-y-auto animate-slide-up">
        <div className="sticky top-0 bg-white p-4 border-b flex justify-between items-center">
          <h3 className="font-serif text-lg font-bold">{title}</h3>
          <button onClick={onClose} className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center">
            <X className="w-4 h-4" />
          </button>
        </div>
        <div className="p-4">{children}</div>
      </div>
    </div>
  );
}
