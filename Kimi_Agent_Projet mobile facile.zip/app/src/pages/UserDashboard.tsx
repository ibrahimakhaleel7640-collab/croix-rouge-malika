import { useState, useEffect } from 'react';
import { useAuth } from '@/context/AuthContext';
import { useNotifications } from '@/components/Notifications';
import { DB, roleLabel, statusBadge, statusLabel } from '@/data/db';
import { User, Calendar, DollarSign, Edit, Save } from 'lucide-react';

export function UserDashboard() {
  const { currentUser, updateUser } = useAuth();
  const { showNotification } = useNotifications();
  const [activeTab, setActiveTab] = useState('profile');
  const [editForm, setEditForm] = useState({
    prenom: '',
    nom: '',
    tel: '',
    adresse: '',
    competences: ''
  });
  const [showMobileMenu, setShowMobileMenu] = useState(false);

  useEffect(() => {
    if (currentUser) {
      setEditForm({
        prenom: currentUser.prenom,
        nom: currentUser.nom,
        tel: currentUser.tel || '',
        adresse: currentUser.adresse || '',
        competences: currentUser.competences || ''
      });
    }
  }, [currentUser]);

  if (!currentUser) return null;

  const myParts = DB.participants.filter(p => p.userId === currentUser.id);
  const myCot = DB.finances.filter(f => f.userId === currentUser.id);
  const myCotTotal = myCot.reduce((s, f) => s + f.montant, 0);
  const myActs = myParts.map(p => ({
    ...DB.activities.find(a => a.id === p.actId),
    role: p.role
  })).filter(a => a.id);

  const handleSaveProfile = () => {
    updateUser(editForm);
    showNotification('success', 'Profil mis à jour', 'Vos informations ont été sauvegardées.');
  };

  const getInitials = () => {
    return (currentUser.prenom[0] + currentUser.nom[0]).toUpperCase();
  };

  const sidebarItems = [
    { id: 'profile', icon: <User className="w-5 h-5" />, label: 'Profil', shortLabel: 'Profil' },
    { id: 'activities', icon: <Calendar className="w-5 h-5" />, label: 'Mes Activités', shortLabel: 'Activités' },
    { id: 'cotisations', icon: <DollarSign className="w-5 h-5" />, label: 'Mes Cotisations', shortLabel: 'Cotisations' }
  ];

  return (
    <div className="min-h-[calc(100vh-70px)] bg-[#FAF7F2]">
      {/* Desktop Sidebar */}
      <div className="hidden md:block w-64 bg-[#1A1A1A] text-white py-6 fixed h-[calc(100vh-70px)] overflow-y-auto">
        <div className="px-4 mb-6">
          <div className="text-xs uppercase tracking-wider text-white/40 mb-4">Mon Espace</div>
          {sidebarItems.map(item => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-3 rounded-lg mb-1 transition-colors ${
                activeTab === item.id ? 'bg-[#CC0000]' : 'hover:bg-white/10 text-white/70'
              }`}
            >
              {item.icon}
              <span className="text-sm font-medium">{item.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Mobile Header */}
      <div className="md:hidden bg-white border-b border-gray-200 px-4 py-3 flex items-center justify-between sticky top-[70px] z-30">
        <button 
          onClick={() => setShowMobileMenu(!showMobileMenu)}
          className="flex items-center gap-2 text-[#CC0000] font-medium"
        >
          {sidebarItems.find(i => i.id === activeTab)?.icon}
          <span>{sidebarItems.find(i => i.id === activeTab)?.label}</span>
        </button>
        {showMobileMenu && (
          <div className="absolute top-full left-0 right-0 bg-white border-b border-gray-200 shadow-lg">
            {sidebarItems.filter(i => i.id !== activeTab).map(item => (
              <button
                key={item.id}
                onClick={() => { setActiveTab(item.id); setShowMobileMenu(false); }}
                className="w-full flex items-center gap-3 px-4 py-3 hover:bg-red-50 text-left"
              >
                {item.icon}
                <span>{item.label}</span>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Main Content */}
      <div className="md:ml-64 p-4 md:p-8 pb-24 md:pb-8">
        {/* Profile Tab */}
        {activeTab === 'profile' && (
          <div>
            <h2 className="font-serif text-xl md:text-2xl font-bold text-[#1A1A1A] mb-4 md:mb-6">Mon Profil</h2>
            
            <div className="grid lg:grid-cols-3 gap-4 md:gap-6">
              {/* Profile Card */}
              <div className="bg-white rounded-xl shadow-[0_4px_24px_rgba(0,0,0,0.08)] overflow-hidden">
                <div className="h-16 md:h-24 bg-gradient-to-r from-[#990000] to-[#CC0000]"></div>
                <div className="px-4 md:px-6 pb-4 md:pb-6">
                  <div className="w-16 h-16 md:w-20 md:h-20 bg-[#CC0000] rounded-full border-4 border-white flex items-center justify-center text-white text-xl md:text-2xl font-bold -mt-8 md:-mt-10 mb-3 md:mb-4">
                    {getInitials()}
                  </div>
                  <h3 className="font-serif text-lg md:text-xl font-bold">{currentUser.prenom} {currentUser.nom}</h3>
                  <p className="text-gray-500 text-sm">{roleLabel(currentUser.role)}</p>
                  <div className="mt-3 md:mt-4 space-y-1 text-xs md:text-sm text-gray-600">
                    <div className="break-all">✉️ {currentUser.email}</div>
                    <div>📞 {currentUser.tel || '—'}</div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-2 md:gap-3 mt-4 md:mt-6">
                    <div className="bg-[#FAF7F2] rounded-lg p-3 md:p-4 text-center">
                      <div className="font-serif text-xl md:text-2xl font-bold text-[#CC0000]">{myParts.length}</div>
                      <div className="text-[0.6rem] md:text-xs text-gray-500 uppercase tracking-wide">Activités</div>
                    </div>
                    <div className="bg-[#FAF7F2] rounded-lg p-3 md:p-4 text-center">
                      <div className="font-serif text-xl md:text-2xl font-bold text-[#CC0000]">{myCotTotal.toLocaleString()}</div>
                      <div className="text-[0.6rem] md:text-xs text-gray-500 uppercase tracking-wide">FCFA</div>
                    </div>
                  </div>
                  
                  <div className="mt-3 md:mt-4">
                    <span className={`inline-flex px-2 md:px-3 py-1 rounded-full text-[0.65rem] md:text-xs font-bold uppercase ${statusBadge(currentUser.statut)}`}>
                      ✅ {currentUser.statut === 'actif' ? 'Actif' : currentUser.statut === 'en-attente' ? 'En attente' : 'Suspendu'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Edit Form */}
              <div className="lg:col-span-2 bg-white rounded-xl shadow-[0_4px_24px_rgba(0,0,0,0.08)] p-4 md:p-6">
                <h3 className="font-serif text-base md:text-lg font-bold mb-4 md:mb-6 flex items-center gap-2">
                  <Edit className="w-4 md:w-5 h-4 md:h-5" />
                  Modifier mes informations
                </h3>
                
                <div className="space-y-4 md:space-y-5">
                  <div className="grid md:grid-cols-2 gap-4 md:gap-5">
                    <div>
                      <label className="block text-xs font-semibold uppercase tracking-wide mb-1.5 md:mb-2">Prénom</label>
                      <input
                        type="text"
                        value={editForm.prenom}
                        onChange={(e) => setEditForm(prev => ({ ...prev, prenom: e.target.value }))}
                        className="w-full px-3 md:px-4 py-2.5 md:py-3 border-2 border-[#E8E4DF] rounded-lg focus:border-[#CC0000] focus:outline-none bg-[#FAF7F2] focus:bg-white transition-colors text-sm"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold uppercase tracking-wide mb-1.5 md:mb-2">Nom</label>
                      <input
                        type="text"
                        value={editForm.nom}
                        onChange={(e) => setEditForm(prev => ({ ...prev, nom: e.target.value }))}
                        className="w-full px-3 md:px-4 py-2.5 md:py-3 border-2 border-[#E8E4DF] rounded-lg focus:border-[#CC0000] focus:outline-none bg-[#FAF7F2] focus:bg-white transition-colors text-sm"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wide mb-1.5 md:mb-2">Téléphone</label>
                    <input
                      type="tel"
                      value={editForm.tel}
                      onChange={(e) => setEditForm(prev => ({ ...prev, tel: e.target.value }))}
                      className="w-full px-3 md:px-4 py-2.5 md:py-3 border-2 border-[#E8E4DF] rounded-lg focus:border-[#CC0000] focus:outline-none bg-[#FAF7F2] focus:bg-white transition-colors text-sm"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wide mb-1.5 md:mb-2">Adresse</label>
                    <input
                      type="text"
                      value={editForm.adresse}
                      onChange={(e) => setEditForm(prev => ({ ...prev, adresse: e.target.value }))}
                      className="w-full px-3 md:px-4 py-2.5 md:py-3 border-2 border-[#E8E4DF] rounded-lg focus:border-[#CC0000] focus:outline-none bg-[#FAF7F2] focus:bg-white transition-colors text-sm"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wide mb-1.5 md:mb-2">Compétences</label>
                    <input
                      type="text"
                      value={editForm.competences}
                      onChange={(e) => setEditForm(prev => ({ ...prev, competences: e.target.value }))}
                      className="w-full px-3 md:px-4 py-2.5 md:py-3 border-2 border-[#E8E4DF] rounded-lg focus:border-[#CC0000] focus:outline-none bg-[#FAF7F2] focus:bg-white transition-colors text-sm"
                    />
                  </div>
                  
                  <button
                    onClick={handleSaveProfile}
                    className="flex items-center justify-center md:justify-start gap-2 w-full md:w-auto px-4 md:px-6 py-2.5 md:py-3 bg-[#CC0000] text-white rounded-lg font-semibold hover:bg-[#990000] transition-colors text-sm"
                  >
                    <Save className="w-4 h-4" /> Sauvegarder
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Activities Tab */}
        {activeTab === 'activities' && (
          <div>
            <h2 className="font-serif text-xl md:text-2xl font-bold text-[#1A1A1A] mb-4 md:mb-6">Mes Participations</h2>
            
            {myActs.length === 0 ? (
              <div className="text-center py-12 md:py-16 bg-white rounded-xl shadow-[0_4px_24px_rgba(0,0,0,0.08)]">
                <div className="text-4xl md:text-5xl mb-4">📅</div>
                <h3 className="text-base md:text-lg font-semibold mb-2">Aucune participation</h3>
                <p className="text-gray-500 text-sm">Vous n'avez pas encore participé à une activité.</p>
              </div>
            ) : (
              <>
                {/* Mobile Cards */}
                <div className="md:hidden space-y-3">
                  {myActs.map((act: any, i) => (
                    <div key={i} className="bg-white rounded-xl p-4 shadow-[0_4px_24px_rgba(0,0,0,0.08)]">
                      <div className="font-semibold text-sm mb-2">{act.nom}</div>
                      <div className="text-xs text-gray-500 space-y-1">
                        <div>📅 {act.date}</div>
                        <div>📍 {act.lieu}</div>
                      </div>
                      <div className="flex gap-2 mt-3">
                        <span className={`px-2 py-1 rounded-full text-[0.65rem] font-bold uppercase ${statusBadge(act.statut)}`}>
                          {statusLabel(act.statut)}
                        </span>
                        <span className="px-2 py-1 rounded-full text-[0.65rem] font-bold uppercase bg-blue-100 text-blue-700">
                          {act.role}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
                
                {/* Desktop Table */}
                <div className="hidden md:block bg-white rounded-xl shadow-[0_4px_24px_rgba(0,0,0,0.08)] overflow-hidden">
                  <table className="w-full">
                    <thead className="bg-[#FAF7F2]">
                      <tr>
                        <th className="px-6 py-4 text-left text-xs font-bold uppercase tracking-wider text-gray-500">Activité</th>
                        <th className="px-6 py-4 text-left text-xs font-bold uppercase tracking-wider text-gray-500">Date</th>
                        <th className="px-6 py-4 text-left text-xs font-bold uppercase tracking-wider text-gray-500">Lieu</th>
                        <th className="px-6 py-4 text-left text-xs font-bold uppercase tracking-wider text-gray-500">Statut</th>
                        <th className="px-6 py-4 text-left text-xs font-bold uppercase tracking-wider text-gray-500">Mon rôle</th>
                      </tr>
                    </thead>
                    <tbody>
                      {myActs.map((act: any, i) => (
                        <tr key={i} className="border-t border-[#E8E4DF] hover:bg-red-50 transition-colors">
                          <td className="px-6 py-4 font-semibold">{act.nom}</td>
                          <td className="px-6 py-4">{act.date}</td>
                          <td className="px-6 py-4">{act.lieu}</td>
                          <td className="px-6 py-4">
                            <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase ${statusBadge(act.statut)}`}>
                              {statusLabel(act.statut)}
                            </span>
                          </td>
                          <td className="px-6 py-4">
                            <span className="px-3 py-1 rounded-full text-xs font-bold uppercase bg-blue-100 text-blue-700">
                              {act.role}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </>
            )}
          </div>
        )}

        {/* Cotisations Tab */}
        {activeTab === 'cotisations' && (
          <div>
            <h2 className="font-serif text-xl md:text-2xl font-bold text-[#1A1A1A] mb-4 md:mb-6">Mes Cotisations</h2>
            
            {myCot.length === 0 ? (
              <div className="text-center py-12 md:py-16 bg-white rounded-xl shadow-[0_4px_24px_rgba(0,0,0,0.08)]">
                <div className="text-4xl md:text-5xl mb-4">💰</div>
                <h3 className="text-base md:text-lg font-semibold mb-2">Aucune cotisation</h3>
                <p className="text-gray-500 text-sm">Vous n'avez pas encore effectué de cotisation.</p>
              </div>
            ) : (
              <>
                {/* Mobile Cards */}
                <div className="md:hidden space-y-3">
                  {myCot.map((cot, i) => (
                    <div key={i} className="bg-white rounded-xl p-4 shadow-[0_4px_24px_rgba(0,0,0,0.08)]">
                      <div className="flex justify-between items-start mb-2">
                        <span className="font-bold text-[#CC0000]">{cot.montant.toLocaleString()} FCFA</span>
                        <span className={`px-2 py-1 rounded-full text-[0.65rem] font-bold uppercase ${
                          cot.type === 'cotisation' ? 'bg-blue-100 text-blue-700' :
                          cot.type === 'don' ? 'bg-green-100 text-green-700' :
                          'bg-amber-100 text-amber-700'
                        }`}>
                          {cot.type}
                        </span>
                      </div>
                      <div className="text-xs text-gray-500 space-y-1">
                        <div>{cot.mode}</div>
                        <div>{cot.date}</div>
                      </div>
                    </div>
                  ))}
                </div>
                
                {/* Desktop Table */}
                <div className="hidden md:block bg-white rounded-xl shadow-[0_4px_24px_rgba(0,0,0,0.08)] overflow-hidden">
                  <table className="w-full">
                    <thead className="bg-[#FAF7F2]">
                      <tr>
                        <th className="px-6 py-4 text-left text-xs font-bold uppercase tracking-wider text-gray-500">Montant</th>
                        <th className="px-6 py-4 text-left text-xs font-bold uppercase tracking-wider text-gray-500">Type</th>
                        <th className="px-6 py-4 text-left text-xs font-bold uppercase tracking-wider text-gray-500">Mode</th>
                        <th className="px-6 py-4 text-left text-xs font-bold uppercase tracking-wider text-gray-500">Référence</th>
                        <th className="px-6 py-4 text-left text-xs font-bold uppercase tracking-wider text-gray-500">Date</th>
                      </tr>
                    </thead>
                    <tbody>
                      {myCot.map((cot, i) => (
                        <tr key={i} className="border-t border-[#E8E4DF] hover:bg-red-50 transition-colors">
                          <td className="px-6 py-4 font-bold">{cot.montant.toLocaleString()} FCFA</td>
                          <td className="px-6 py-4">
                            <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase ${
                              cot.type === 'cotisation' ? 'bg-blue-100 text-blue-700' :
                              cot.type === 'don' ? 'bg-green-100 text-green-700' :
                              'bg-amber-100 text-amber-700'
                            }`}>
                              {cot.type}
                            </span>
                          </td>
                          <td className="px-6 py-4">{cot.mode}</td>
                          <td className="px-6 py-4">
                            <code className="bg-[#FAF7F2] px-2 py-1 rounded text-xs">{cot.ref}</code>
                          </td>
                          <td className="px-6 py-4">{cot.date}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </>
            )}
          </div>
        )}
      </div>

      {/* Mobile Bottom Navigation */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-2 py-2 flex justify-around z-40">
        {sidebarItems.map(item => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={`flex flex-col items-center gap-1 px-3 py-2 rounded-lg transition-colors ${
              activeTab === item.id ? 'text-[#CC0000]' : 'text-gray-500'
            }`}
          >
            {item.icon}
            <span className="text-[0.65rem] font-medium">{item.shortLabel}</span>
          </button>
        ))}
      </div>
    </div>
  );
}
