import { useState } from 'react';
import { useAuth } from '@/context/AuthContext';
import { useNotifications } from '@/components/Notifications';
import { AlertCircle, Mail, Lock } from 'lucide-react';

interface LoginProps {
  onNavigate: (page: string) => void;
}

export function Login({ onNavigate }: LoginProps) {
  const { login } = useAuth();
  const { showNotification } = useNotifications();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!email || !password) {
      setError('Veuillez remplir tous les champs.');
      return;
    }

    if (login(email, password)) {
      showNotification('success', 'Connexion réussie !', 'Bienvenue sur votre espace Croix-Rouge Malika.');
    } else {
      setError('Email ou mot de passe incorrect.');
    }
  };

  return (
    <div className="min-h-[calc(100vh-70px)] flex items-center justify-center p-4 md:p-8 bg-gradient-to-br from-[#FAF7F2] to-[#F5EEE8]">
      <div className="bg-white rounded-2xl shadow-[0_8px_48px_rgba(0,0,0,0.16)] w-full max-w-md overflow-hidden">
        <div className="bg-[#CC0000] text-white p-6 md:p-8 text-center">
          <div className="text-3xl md:text-4xl mb-2 md:mb-3">✚</div>
          <h2 className="font-serif text-xl md:text-2xl font-bold">Connexion</h2>
          <p className="text-xs md:text-sm opacity-85 mt-1 md:mt-2">Accédez à votre espace Croix-Rouge Malika</p>
        </div>
        
        <div className="p-5 md:p-8">
          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-4 md:mb-6 flex items-center gap-2 text-sm">
              <AlertCircle className="w-5 h-5 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}
          
          <form onSubmit={handleSubmit} className="space-y-4 md:space-y-5">
            <div>
              <label className="block text-xs font-semibold text-[#2D2D2D] uppercase tracking-wide mb-2">
                Adresse e-mail
              </label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="votre@email.com"
                  className="w-full pl-10 pr-4 py-3 border-2 border-[#E8E4DF] rounded-lg focus:border-[#CC0000] focus:outline-none bg-[#FAF7F2] focus:bg-white transition-colors text-sm"
                />
              </div>
            </div>
            
            <div>
              <label className="block text-xs font-semibold text-[#2D2D2D] uppercase tracking-wide mb-2">
                Mot de passe
              </label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-10 pr-4 py-3 border-2 border-[#E8E4DF] rounded-lg focus:border-[#CC0000] focus:outline-none bg-[#FAF7F2] focus:bg-white transition-colors text-sm"
                />
              </div>
            </div>
            
            <button
              type="submit"
              className="w-full py-3 md:py-4 bg-[#CC0000] text-white rounded-lg font-semibold hover:bg-[#990000] transition-colors active:scale-[0.98]"
            >
              🔐 Se connecter
            </button>
          </form>
          
          <div className="mt-4 md:mt-6">
            <div className="text-xs md:text-sm font-semibold mb-2 md:mb-3">Comptes de démonstration :</div>
            <div className="text-[0.65rem] md:text-xs text-gray-500 space-y-1 bg-gray-50 p-3 md:p-4 rounded-lg">
              <div>🔴 Super Admin: <strong>admin@croix-rouge-malika.sn</strong> / <strong>admin123</strong></div>
              <div>🟠 Admin: <strong>resp@croix-rouge-malika.sn</strong> / <strong>resp123</strong></div>
              <div>🟢 Volontaire: <strong>fatou@example.com</strong> / <strong>vol123</strong></div>
            </div>
          </div>
          
          <div className="mt-4 md:mt-6 text-center text-sm text-gray-500">
            Pas encore inscrit ?{' '}
            <button 
              onClick={() => onNavigate('register')}
              className="text-[#CC0000] font-medium hover:underline"
            >
              S'inscrire
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
