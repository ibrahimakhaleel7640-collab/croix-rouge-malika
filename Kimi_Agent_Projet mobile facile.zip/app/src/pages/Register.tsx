import { useState } from 'react';
import { useAuth } from '@/context/AuthContext';
import { useNotifications } from '@/components/Notifications';
import { AlertCircle, User, Mail, Phone, Lock, MapPin, Calendar, Briefcase, FileText } from 'lucide-react';

interface RegisterProps {
  onNavigate: (page: string) => void;
}

export function Register({ onNavigate }: RegisterProps) {
  const { register } = useAuth();
  const { showNotification } = useNotifications();
  const [formData, setFormData] = useState({
    prenom: '',
    nom: '',
    email: '',
    tel: '',
    password: '',
    dob: '',
    adresse: '',
    competences: '',
    experiences: ''
  });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const result = register(formData);
    
    if (result.success) {
      setSuccess(true);
      showNotification('success', 'Inscription réussie !', result.message);
      setTimeout(() => onNavigate('login'), 3000);
    } else {
      setError(result.message);
    }
  };

  if (success) {
    return (
      <div className="min-h-[calc(100vh-70px)] flex items-center justify-center p-4 md:p-8 bg-gradient-to-br from-[#FAF7F2] to-[#F5EEE8]">
        <div className="bg-white rounded-2xl shadow-[0_8px_48px_rgba(0,0,0,0.16)] w-full max-w-md p-6 md:p-8 text-center">
          <div className="text-4xl md:text-5xl mb-4">✅</div>
          <h2 className="font-serif text-xl md:text-2xl font-bold text-[#1A1A1A] mb-3">Inscription réussie !</h2>
          <p className="text-gray-600 text-sm mb-6">{error || 'Votre compte a été créé avec succès. Vous allez être redirigé vers la page de connexion.'}</p>
          <button
            onClick={() => onNavigate('login')}
            className="px-6 py-3 bg-[#CC0000] text-white rounded-lg font-semibold hover:bg-[#990000] transition-colors"
          >
            Aller à la connexion
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-[calc(100vh-70px)] flex items-start justify-center p-4 md:p-8 bg-gradient-to-br from-[#FAF7F2] to-[#F5EEE8] pb-24">
      <div className="bg-white rounded-2xl shadow-[0_8px_48px_rgba(0,0,0,0.16)] w-full max-w-2xl overflow-hidden">
        <div className="bg-[#CC0000] text-white p-6 md:p-8 text-center">
          <div className="text-3xl md:text-4xl mb-2 md:mb-3">📝</div>
          <h2 className="font-serif text-xl md:text-2xl font-bold">Inscription Volontaire</h2>
          <p className="text-xs md:text-sm opacity-85 mt-1 md:mt-2">Rejoignez la Croix-Rouge de Malika</p>
        </div>
        
        <div className="p-5 md:p-8">
          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-4 md:mb-6 flex items-center gap-2 text-sm">
              <AlertCircle className="w-5 h-5 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}
          
          <form onSubmit={handleSubmit} className="space-y-4 md:space-y-5">
            <div className="grid md:grid-cols-2 gap-4 md:gap-5">
              <div>
                <label className="block text-xs font-semibold text-[#2D2D2D] uppercase tracking-wide mb-2">
                  Prénom *
                </label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="text"
                    name="prenom"
                    value={formData.prenom}
                    onChange={handleChange}
                    placeholder="Prénom"
                    className="w-full pl-10 pr-4 py-3 border-2 border-[#E8E4DF] rounded-lg focus:border-[#CC0000] focus:outline-none bg-[#FAF7F2] focus:bg-white transition-colors text-sm"
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-xs font-semibold text-[#2D2D2D] uppercase tracking-wide mb-2">
                  Nom *
                </label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="text"
                    name="nom"
                    value={formData.nom}
                    onChange={handleChange}
                    placeholder="Nom de famille"
                    className="w-full pl-10 pr-4 py-3 border-2 border-[#E8E4DF] rounded-lg focus:border-[#CC0000] focus:outline-none bg-[#FAF7F2] focus:bg-white transition-colors text-sm"
                  />
                </div>
              </div>
            </div>
            
            <div className="grid md:grid-cols-2 gap-4 md:gap-5">
              <div>
                <label className="block text-xs font-semibold text-[#2D2D2D] uppercase tracking-wide mb-2">
                  Email *
                </label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="email@example.com"
                    className="w-full pl-10 pr-4 py-3 border-2 border-[#E8E4DF] rounded-lg focus:border-[#CC0000] focus:outline-none bg-[#FAF7F2] focus:bg-white transition-colors text-sm"
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-xs font-semibold text-[#2D2D2D] uppercase tracking-wide mb-2">
                  Téléphone *
                </label>
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="tel"
                    name="tel"
                    value={formData.tel}
                    onChange={handleChange}
                    placeholder="+221 7X XXX XX XX"
                    className="w-full pl-10 pr-4 py-3 border-2 border-[#E8E4DF] rounded-lg focus:border-[#CC0000] focus:outline-none bg-[#FAF7F2] focus:bg-white transition-colors text-sm"
                  />
                </div>
              </div>
            </div>
            
            <div className="grid md:grid-cols-2 gap-4 md:gap-5">
              <div>
                <label className="block text-xs font-semibold text-[#2D2D2D] uppercase tracking-wide mb-2">
                  Mot de passe *
                </label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="password"
                    name="password"
                    value={formData.password}
                    onChange={handleChange}
                    placeholder="Min. 6 caractères"
                    className="w-full pl-10 pr-4 py-3 border-2 border-[#E8E4DF] rounded-lg focus:border-[#CC0000] focus:outline-none bg-[#FAF7F2] focus:bg-white transition-colors text-sm"
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-xs font-semibold text-[#2D2D2D] uppercase tracking-wide mb-2">
                  Date de naissance
                </label>
                <div className="relative">
                  <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="date"
                    name="dob"
                    value={formData.dob}
                    onChange={handleChange}
                    className="w-full pl-10 pr-4 py-3 border-2 border-[#E8E4DF] rounded-lg focus:border-[#CC0000] focus:outline-none bg-[#FAF7F2] focus:bg-white transition-colors text-sm"
                  />
                </div>
              </div>
            </div>
            
            <div>
              <label className="block text-xs font-semibold text-[#2D2D2D] uppercase tracking-wide mb-2">
                Adresse
              </label>
              <div className="relative">
                <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  name="adresse"
                  value={formData.adresse}
                  onChange={handleChange}
                  placeholder="Quartier, Malika, Dakar"
                  className="w-full pl-10 pr-4 py-3 border-2 border-[#E8E4DF] rounded-lg focus:border-[#CC0000] focus:outline-none bg-[#FAF7F2] focus:bg-white transition-colors text-sm"
                />
              </div>
            </div>
            
            <div>
              <label className="block text-xs font-semibold text-[#2D2D2D] uppercase tracking-wide mb-2">
                Compétences
              </label>
              <div className="relative">
                <Briefcase className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  name="competences"
                  value={formData.competences}
                  onChange={handleChange}
                  placeholder="Premiers secours, soins infirmiers, informatique..."
                  className="w-full pl-10 pr-4 py-3 border-2 border-[#E8E4DF] rounded-lg focus:border-[#CC0000] focus:outline-none bg-[#FAF7F2] focus:bg-white transition-colors text-sm"
                />
              </div>
            </div>
            
            <div>
              <label className="block text-xs font-semibold text-[#2D2D2D] uppercase tracking-wide mb-2">
                Expériences
              </label>
              <div className="relative">
                <FileText className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
                <textarea
                  name="experiences"
                  value={formData.experiences}
                  onChange={handleChange}
                  rows={3}
                  placeholder="Décrivez vos expériences de bénévolat..."
                  className="w-full pl-10 pr-4 py-3 border-2 border-[#E8E4DF] rounded-lg focus:border-[#CC0000] focus:outline-none bg-[#FAF7F2] focus:bg-white transition-colors resize-none text-sm"
                />
              </div>
            </div>
            
            <button
              type="submit"
              className="w-full py-3 md:py-4 bg-[#CC0000] text-white rounded-lg font-semibold hover:bg-[#990000] transition-colors active:scale-[0.98]"
            >
              ✅ Créer mon compte
            </button>
          </form>
          
          <div className="mt-4 md:mt-6 text-center text-sm text-gray-500">
            Déjà inscrit ?{' '}
            <button 
              onClick={() => onNavigate('login')}
              className="text-[#CC0000] font-medium hover:underline"
            >
              Se connecter
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
