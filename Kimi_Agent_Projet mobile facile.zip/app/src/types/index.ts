// Types pour l'application Croix-Rouge Malika

export type UserRole = 'super_admin' | 'admin' | 'volontaire' | 'chef_equipe';
export type UserStatus = 'actif' | 'en-attente' | 'suspendu';
export type ActivityStatus = 'prevue' | 'en-cours' | 'terminee';
export type FinanceType = 'cotisation' | 'don' | 'frais_activite';
export type PaymentMode = 'cash' | 'wave' | 'orange_money' | 'free_money' | 'virement';

export interface User {
  id: number;
  prenom: string;
  nom: string;
  email: string;
  password: string;
  tel?: string;
  adresse?: string;
  dob?: string;
  competences?: string;
  experiences?: string;
  cv?: string | null;
  role: UserRole;
  statut: UserStatus;
  created: string;
}

export interface Activity {
  id: number;
  nom: string;
  desc?: string;
  date: string;
  lieu?: string;
  statut: ActivityStatus;
  limite: number;
  chefId?: number | null;
  created?: string;
}

export interface Participant {
  id: number;
  userId: number;
  actId: number;
  role: string;
  date: string;
}

export interface Finance {
  id: number;
  userId: number;
  montant: number;
  type: FinanceType;
  mode: PaymentMode;
  ref: string;
  date: string;
  actId?: number | null;
}

export interface Admin {
  id: number;
  prenom: string;
  nom: string;
  email: string;
  role: UserRole;
  lastAccess: string;
}

export interface Notification {
  id: number;
  type: 'success' | 'error' | 'info' | 'warning';
  title: string;
  msg: string;
  read: boolean;
  time: string;
}

export interface Database {
  users: User[];
  activities: Activity[];
  participants: Participant[];
  finances: Finance[];
  admins: Admin[];
  notifications: Notification[];
  nextId: {
    users: number;
    activities: number;
    participants: number;
    finances: number;
    admins: number;
  };
}
